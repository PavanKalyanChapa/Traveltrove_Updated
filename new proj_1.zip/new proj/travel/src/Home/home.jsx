import React from "react";
import { useNavigate } from "react-router-dom";
import { useEffect, useState } from 'react';
import axios from 'axios';
import { FaFacebook, FaInstagram, FaTwitter, FaYoutube } from "react-icons/fa";
import DestinationCard from '../components/Destination/DestinationCard';
import HomeReviews from "../components/HomeReviews";
import Groups from '../components/groups/Groups';
import { Link } from "react-router-dom";
export default function Home() {
    const navigate = useNavigate();
    const [destinations, setDestinations] = useState([]);
    const fetchDestinations = async () => {
        try {
            const response = await axios.get("http://localhost:5000/destinations");
            setDestinations(Array.isArray(response.data) ? response.data : []);
        } catch (error) {
            console.log(error);
        }
    }
    useEffect(() => {
        fetchDestinations();
    }, []);
    const [searchTerm, setSearchTerm] = useState("");
    const [results, setResults] = useState([]);
    const [isSearch, setIsSearch] = useState(false);
    const handleSearch = (e) => {
        const term = e.target.value;
        setSearchTerm(term);
        const searchWords = term.trim().split(' ').filter(word=>word!=='');
        if (term === "") {
            setResults([]);
            setIsSearch(false);
            return;
        }
        setIsSearch(true);
        const filterGuides = destinations.filter((guide) => {
            return searchWords.every((word) => {
                return guide.title.toLowerCase().includes(word.toLowerCase()) || guide.destinationSummary.toLowerCase().includes(word.toLowerCase());
            });
        });
        // Sort by relevance (number of matching words) and then by rating
        const sortedResults = filterGuides.sort((a, b) => {
            const aMatches = searchWords.filter(word =>
                a.title.toLowerCase().includes(word.toLowerCase()) || a.destinationSummary.toLowerCase().includes(word.toLowerCase())
            ).length;
            const bMatches = searchWords.filter(word =>
                b.title.toLowerCase().includes(word.toLowerCase()) || b.destinationSummary.toLowerCase().includes(word.toLowerCase())
            ).length;
            if (bMatches !== aMatches) {
                return bMatches - aMatches; // More matches first
            }
            return b.rating - a.rating; // Higher rating first
        });
        setResults(sortedResults);
    }
    const clearSearch = () => {
        setSearchTerm("");
        setResults([]);
        setIsSearch(false);
        return;
    }
    const [hover, setHover] = useState(false);
    const btnStyle = {
        backgroundColor: hover ? "#d89001" : "#F1A501",
        border: "none",
        padding: "0.5rem 1.5rem",
        fontSize: "1.1rem",
        fontWeight: "600",
        borderRadius: "8px",
        color:"white",
        cursor: "pointer",
        transform: hover ? "translateY(-1px)" : "translateY(0)",
        transition: "all 0.2s ease"
    };
    const MAX_CARDS_TO_SHOW = 6; // Show 6 cards (2 rows x 3 cards per row)
    let display = searchTerm.length > 0
        ? results.slice(0, MAX_CARDS_TO_SHOW)
        : destinations.slice(0, MAX_CARDS_TO_SHOW);
    return (
        <div>
            {/* ----------------- Hero Section -------------------- */}
            <section className="hero">
                <div className="left-container">
                    <div className="left-content">
                        <h4>Best Destinations around the world</h4>
                        <h1>Travel, enjoy and live a new and full life</h1>
                        <p>
                            Travel opens your heart, broadens your mind, and <br /> fills your life with stories to tell
                        </p>

                        {/* Search Bar instead of buttons */}
                        <div className="search-section">
                            <div className="input-group">
                                <input
                                    type="text"
                                    className="form-control"
                                    placeholder="Search destinations by name, description"
                                    value={searchTerm}
                                    onChange={handleSearch}
                                />
                                {searchTerm && (
                                    <button className="btn-sub" onClick={clearSearch}>
                                        Clear
                                    </button>
                                )}
                            </div>
                        </div>
                    </div>
                </div>
                <div className="right-container">
                    <img src="./slide-2.png" alt="Hero" width="580px" />
                </div>
            </section>

            {/* ------------------ Featured Destinations ---------------------- */}
            <section className="py-5 ">
                <div className="container">
                    <div className="text-center mb-5">
                        {searchTerm ? (
                            <>
                                <div class="category-title">
                                    <h3>Search Results for "{searchTerm}"</h3>
                                </div>
                            </>
                        ) : (
                            <>
                                <div class="category-title">
                                    <h3>Featured Destination</h3>
                                    <h5>Discover our most popular destination guides</h5>
                                </div>
                            </>
                        )}
                    </div>
                    {isSearch && results.length === 0 && searchTerm && (
                        <div className="text-center py-4">
                            <div className="alert alert-info">
                                No destinations found matching your search. Try different key words.
                            </div>
                        </div>
                    )}
                    <div className="container my-5">
                        <div className="card-grid">
                            {display.map((dest) => (
                                <div key={dest.destinationId}>
                                    <DestinationCard guide={dest} />
                                </div>
                            ))}
                        </div>
                    </div>
                    <div className="text-center mt-5">
                        <button
                            className="contact-btn btn-lg"
                            onClick={() => navigate("/destinations")}
                        >
                            View All Destinations
                        </button>
                    </div>
                </div>
            </section>


            {/* Travel Groups */}
            <section className="py-5">
                <div className="container text-center">
                    <Groups />
                    <div className="d-flex flex-column flex-sm-row justify-content-center gap-3 mt-5">
                        <button
                            className="contact-btn btn-lg"
                            onClick={() => navigate("/groups")}>
                            Browse All Groups
                        </button>
                    </div>
                </div>
            </section>

            {/* Reviews */}
            <section className="py-5 bg-light">
                <div className="container text-center">
                    <div className="row g-4">
                        <HomeReviews />
                    </div>
                </div>
            </section>
            {/* ===============================================*/}
            {/*    Footer */}
            {/* ===============================================*/}
            <section>
                <div className="footer redesigned-footer">
                    <div className="footer-col f-col-1">
                        <img src="./logo.svg" alt="footer-logo" width="150" style={{marginLeft:"-12px"}} />
                        <p>Book your trip in minute, get full Control for much longer.</p>
                    </div>
                    <div className="footer-col footer-links-col">
                        <h4>Company</h4>
                        <ul>
                            <li><Link to="/">Home</Link></li>
                            <li><Link to="/destinations">Destinations</Link></li>
                            <li><Link to="/groups">Groups</Link></li>
                        </ul>
                    </div>
                    <div className="footer-col footer-links-col">
                        <br /><br />
                        <ul>
                            <li><Link to="/reviews">Reviews</Link></li>
                            <li><Link to="/profile">Profile</Link></li>
                            <li><Link to="/login">Login</Link></li>
                        </ul>
                    </div>
                    <div className="footer-col social-col">
                        <div className="social-icons">
                            <a href="#" className="social-icons-item"><FaFacebook /></a>
                            <a href="#" className="social-icons-item"><FaInstagram /></a>
                            <a href="#" className="social-icons-item"><FaTwitter /></a>
                        </div>
                        <h4 className="footer-app">Discover our app</h4>
                        <div>
                            <img src="./play-store.png" alt="playstore" />
                            <img src="./apple-store.png" alt="applestore" />
                        </div>
                    </div>
                </div>
            </section>

            <div className="end-text">
                <p> &copy; All rights Reserved TravelTrove@admin.com 2025</p>
            </div>
        </div>
    );
}

