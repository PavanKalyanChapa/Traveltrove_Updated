import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { AuthProvider } from './contexts/AuthContext';
import './responsive.css';
import Home from './Home/home';
import Navbar from './components/Navbar/navbar';
import DestinationDetails from './components/Destination/DestinationDetails';
import DestinationsPage from './components/Destination/DestinationsPage';
import CreateItinerary from "./components/itinerary/createItinerary";
import ItineraryPage from "./components/itinerary/ItineraryPage";
import ItineraryDetails from "./components/itinerary/ItineraryDetails";
import ReviewsPage from "./components/Destination/ReviewsPage";
import LoginUser from './components/Auth/loginUser';
import RegisterUser from './components/Auth/registerUser';
import FavoritesPage from './components/Favorites/FavoritesPage';
import Groups from "./components/groups/Groups";
import Profile from './components/Profile/Profile';
import AdminDashboard from './components/Admin/AdminDashboard';
import ProtectedRoute from "./components/ProtectedRoute";
function App() {
  return (
    <AuthProvider>
      <Router>
        <Navbar />
        <Routes>
          {/* Public Route */}
          <Route path="/" element={<Home />} />
          {/* Protected Routes */}
          <Route path="/destinations" element={<DestinationsPage />} />
          <Route
            path="/destinations/:id"
            element={
              <ProtectedRoute>
                <DestinationDetails />
              </ProtectedRoute>
            }
          />
          <Route
            path="/create-itinerary/:destinationId"
            element={
              <ProtectedRoute>
                <CreateItinerary />
              </ProtectedRoute>
            }
          />
          <Route
            path="/itineraries"
            element={
              <ProtectedRoute>
                <ItineraryPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/itineraries/:id"
            element={
              <ProtectedRoute>
                <ItineraryDetails />
              </ProtectedRoute>
            }
          />
          <Route
            path="/reviews"
            element={
              <ReviewsPage />
            }
          />
          <Route
            path="/favorites"
            element={
              <ProtectedRoute>
                <FavoritesPage />
              </ProtectedRoute>
            }
          />
          <Route
            path="/groups"
            element={
              <Groups />
            }
          />
          <Route
            path="/admin"
            element={
              <ProtectedRoute>
                <AdminDashboard />
              </ProtectedRoute>
            }
          />
          <Route
            path="/profile"
            element={
              <ProtectedRoute>
                <Profile />
              </ProtectedRoute>
            }
          />
          {/* Public Auth Routes */}
          <Route path="/login" element={<LoginUser />} />
          <Route path="/register" element={<RegisterUser />} />
        </Routes>
      </Router>
    </AuthProvider>
  );
}
export default App;