import React, { createContext, useContext, useState, useEffect } from 'react';
 
const AuthContext = createContext();
 
export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider'); 
  }
  return context; 
};
 
export const AuthProvider = ({ children }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(false); 
  const [token, setToken] = useState(null);
  const [loading, setLoading] = useState(true); 
  const [userObj, setUserObj] = useState({});
  useEffect(() => {
    // Check for existing token on app load 
    const storeddata = localStorage.getItem('userObj');
    const storedToken = localStorage.getItem('token'); 
    if (storedToken && storeddata) {
      setToken(storedToken); 
      setUserObj(JSON.parse(storeddata));
      setIsAuthenticated(true); 
    }
    setLoading(false); 
  }, []);
 
  // Listen for storage changes (e.g., logout in another tab)
 
  useEffect(() => {
    const handleStorageChange = () => { 
      const storedToken = localStorage.getItem('token');
      const storeddata = localStorage.getItem('userObj'); 
      setToken(storedToken);
      setUserObj(JSON.parse(storeddata));
      setIsAuthenticated(!!storedToken); 
    };
    window.addEventListener("storage", handleStorageChange); 
    return () => window.removeEventListener("storage", handleStorageChange);
  }, []); 
  const login = (newToken, userObj) => {
    console.log(userObj); 
    localStorage.setItem('token', newToken);
    localStorage.setItem("userObj", JSON.stringify(userObj)); 
    setToken(newToken);
    setUserObj(userObj); 
    setIsAuthenticated(true);
  }; 
  const logout = () => {
    setToken(null); 
    setUserObj(null);
    setIsAuthenticated(false); 
    localStorage.removeItem('token');
    localStorage.removeItem('userObj'); 
  };
  const value = { 
    isAuthenticated,
    token, 
    loading,
    login, 
    logout,
    userObj, 
  };
 
  return (
    <AuthContext.Provider value={value}> 
      {children}
    </AuthContext.Provider> 
  );
};
 