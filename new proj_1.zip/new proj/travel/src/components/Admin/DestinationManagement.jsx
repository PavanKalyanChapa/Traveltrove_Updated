import React, { useState, useEffect } from 'react';
import { Table, Button, Modal, Form, Alert, Badge, Spinner } from 'react-bootstrap';
import axios from 'axios';

const DestinationManagement = () => {
    const [destinations, setDestinations] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const [showModal, setShowModal] = useState(false);
    const [editingDestination, setEditingDestination] = useState(null);
    const [formData, setFormData] = useState({
        title: '',
        destinationName: '',
        destinationSummary: '',
        history: '',
        culture: '',
        rating: '',
        photo: '',
        touristAttractions: '',
        recommendedHotels: '',
        recommendedRestaurants: '',
        activities: ''
    });

    useEffect(() => {
        fetchDestinations();
    }, []);

    const fetchDestinations = async () => {
        try {
            setLoading(true);
            const response = await axios.get('http://localhost:5000/destinations');
            setDestinations(response.data || []);
            setError('');
        } catch (err) {
            setError('Failed to fetch destinations');
            console.error('Error fetching destinations:', err);
        } finally {
            setLoading(false);
        }
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const token = localStorage.getItem('token');

        if (!token) {
            setError('Authentication required');
            return;
        }

        try {
            // Process form data
            const processedData = {
                ...formData,
                rating: formData.rating ? parseFloat(formData.rating) : 0,
                touristAttractions: formData.touristAttractions ?
                    formData.touristAttractions.split(',').map(item => item.trim()) : [],
                recommendedHotels: formData.recommendedHotels ?
                    JSON.parse(formData.recommendedHotels) : [],
                recommendedRestaurants: formData.recommendedRestaurants ?
                    JSON.parse(formData.recommendedRestaurants) : [],
                activities: formData.activities ?
                    JSON.parse(formData.activities) : []
            };

            if (editingDestination) {
                // Update existing destination
                await axios.put(
                    `http://localhost:5000/admin/destinations/${editingDestination.destinationId}`,
                    processedData,
                    {
                        headers: {
                            'Authorization': `Bearer ${token}`
                        }
                    }
                );
                setSuccess('Destination updated successfully');
            } else {
                // Add new destination
                await axios.post(
                    'http://localhost:5000/admin/destinations',
                    processedData,
                    {
                        headers: {
                            'Authorization': `Bearer ${token}`
                        }
                    }
                );
                setSuccess('Destination added successfully');
            }

            setShowModal(false);
            setEditingDestination(null);
            resetForm();
            fetchDestinations();
        } catch (err) {
            setError(err.response?.data?.error || 'Failed to save destination');
            console.error('Error saving destination:', err);
        }
    };

    const handleEdit = (destination) => {
        setEditingDestination(destination);
        setFormData({
            title: destination.title || '',
            destinationName: destination.destinationName || '',
            destinationSummary: destination.destinationSummary || '',
            history: destination.history || '',
            culture: destination.culture || '',
            rating: destination.rating || '',
            photo: destination.photo || '',
            touristAttractions: destination.touristAttractions ?
                destination.touristAttractions.join(', ') : '',
            recommendedHotels: destination.recommendedHotels ?
                JSON.stringify(destination.recommendedHotels, null, 2) : '',
            recommendedRestaurants: destination.recommendedRestaurants ?
                JSON.stringify(destination.recommendedRestaurants, null, 2) : '',
            activities: destination.activities ?
                JSON.stringify(destination.activities, null, 2) : ''
        });
        setShowModal(true);
    };

    const handleDelete = async (destinationId) => {
        if (!window.confirm('Are you sure you want to delete this destination?')) {
            return;
        }

        const token = localStorage.getItem('token');

        try {
            await axios.delete(
                `http://localhost:5000/admin/destinations/${destinationId}`,
                {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                }
            );
            setSuccess('Destination deleted successfully');
            fetchDestinations();
        } catch (err) {
            setError(err.response?.data?.error || 'Failed to delete destination');
            console.error('Error deleting destination:', err);
        }
    };

    const resetForm = () => {
        setFormData({
            title: '',
            destinationName: '',
            destinationSummary: '',
            history: '',
            culture: '',
            rating: '',
            photo: '',
            touristAttractions: '',
            recommendedHotels: '',
            recommendedRestaurants: '',
            activities: ''
        });
    };

    const handleAddNew = () => {
        setEditingDestination(null);
        resetForm();
        setShowModal(true);
    };

    if (loading) {
        return (
            <div className="loading-spinner">
                <Spinner animation="border" role="status">
                    <span className="visually-hidden">Loading...</span>
                </Spinner>
                <p className="mt-2">Loading destinations...</p>
            </div>
        );
    }

    return (
        <div className="management-section">
            <h2>Destination Management</h2>

            {error && (
                <Alert variant="danger" onClose={() => setError('')} dismissible>
                    {error}
                </Alert>
            )}

            {success && (
                <Alert variant="success" onClose={() => setSuccess('')} dismissible>
                    {success}
                </Alert>
            )}

            <div className="action-buttons">
                <Button className="btn-admin" onClick={handleAddNew}>
                    <i className="bi bi-plus-circle"></i> Add New Destination
                </Button>
            </div>

            {destinations.length === 0 ? (
                <div className="empty-state">
                    <i className="bi bi-geo-alt"></i>
                    <h4>No destinations found</h4>
                    <p>Start by adding your first destination.</p>
                </div>
            ) : (
                <Table responsive className="data-table">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>Destination</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {destinations.map((destination) => (
                            <tr key={destination.destinationId}>
                                <td>{destination.destinationId}</td>
                                <td>{destination.title}</td>
                                <td>{destination.destinationName}</td>
                                <td>

                                    <Button
                                        style={{ backgroundColor: '#F1A501', border: 'none', color: 'white', fontWeight: 600, marginRight: 5 }}
                                        onClick={() => handleEdit(destination)}
                                    >
                                        Edit
                                    </Button>
                                    <Button
                                        style={{ backgroundColor: '#DF6951', border: 'none', color: 'white', fontWeight: 600 }}
                                        onClick={() => handleDelete(destination.destinationId)}
                                    >
                                        Delete
                                    </Button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </Table>
            )}

            {/* Add/Edit Modal */}
            <Modal show={showModal} onHide={() => setShowModal(false)} size="lg">
                <Modal.Header closeButton>
                    <Modal.Title>
                        {editingDestination ? 'Edit Destination' : 'Add New Destination'}
                    </Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form onSubmit={handleSubmit}>
                        <Form.Group className="mb-3">
                            <Form.Label>Title *</Form.Label>
                            <Form.Control
                                type="text"
                                name="title"
                                value={formData.title}
                                onChange={handleInputChange}
                                required
                            />
                        </Form.Group>

                        <Form.Group className="mb-3">
                            <Form.Label>Destination Name *</Form.Label>
                            <Form.Control
                                type="text"
                                name="destinationName"
                                value={formData.destinationName}
                                onChange={handleInputChange}
                                required
                            />
                        </Form.Group>

                        <Form.Group className="mb-3">
                            <Form.Label>Summary *</Form.Label>
                            <Form.Control
                                as="textarea"
                                rows={3}
                                name="destinationSummary"
                                value={formData.destinationSummary}
                                onChange={handleInputChange}
                                required
                            />
                        </Form.Group>

                        <Form.Group className="mb-3">
                            <Form.Label>History</Form.Label>
                            <Form.Control
                                as="textarea"
                                rows={3}
                                name="history"
                                value={formData.history}
                                onChange={handleInputChange}
                            />
                        </Form.Group>

                        <Form.Group className="mb-3">
                            <Form.Label>Culture</Form.Label>
                            <Form.Control
                                as="textarea"
                                rows={3}
                                name="culture"
                                value={formData.culture}
                                onChange={handleInputChange}
                            />
                        </Form.Group>

                        <Form.Group className="mb-3">
                            <Form.Label>Rating</Form.Label>
                            <Form.Control
                                type="number"
                                step="0.1"
                                min="0"
                                max="5"
                                name="rating"
                                value={formData.rating}
                                onChange={handleInputChange}
                            />
                        </Form.Group>

                        <Form.Group className="mb-3">
                            <Form.Label>Photo URL</Form.Label>
                            <Form.Control
                                type="text"
                                name="photo"
                                value={formData.photo}
                                onChange={handleInputChange}
                            />
                        </Form.Group>

                        <Form.Group className="mb-3">
                            <Form.Label>Tourist Attractions (comma-separated)</Form.Label>
                            <Form.Control
                                as="textarea"
                                rows={2}
                                name="touristAttractions"
                                value={formData.touristAttractions}
                                onChange={handleInputChange}
                                placeholder="Attraction 1, Attraction 2, Attraction 3"
                            />
                        </Form.Group>

                        <Form.Group className="mb-3">
                            <Form.Label>Recommended Hotels (JSON format)</Form.Label>
                            <Form.Control
                                as="textarea"
                                rows={4}
                                name="recommendedHotels"
                                value={formData.recommendedHotels}
                                onChange={handleInputChange}
                                placeholder='[{"hotelName": "Hotel Name", "rating": 4.5, "price": 200}]'
                            />
                        </Form.Group>

                        <Form.Group className="mb-3">
                            <Form.Label>Recommended Restaurants (JSON format)</Form.Label>
                            <Form.Control
                                as="textarea"
                                rows={4}
                                name="recommendedRestaurants"
                                value={formData.recommendedRestaurants}
                                onChange={handleInputChange}
                                placeholder='[{"restaurantName": "Restaurant Name", "rating": 4.5, "cuisine": "Italian"}]'
                            />
                        </Form.Group>

                        <Form.Group className="mb-3">
                            <Form.Label>Activities (JSON format)</Form.Label>
                            <Form.Control
                                as="textarea"
                                rows={4}
                                name="activities"
                                value={formData.activities}
                                onChange={handleInputChange}
                                placeholder='[{"name": "Activity Name", "type": "Adventure", "difficulty": "Medium", "duration": "2 hours"}]'
                            />
                        </Form.Group>

                        <div className="d-flex justify-content-end">
                            <Button variant="secondary" onClick={() => setShowModal(false)} style={{ backgroundColor: "#DF6951" ,border:"none"}}>
                                Cancel
                            </Button>
                            <Button type="submit" className="btn-admin">
                                {editingDestination ? 'Update' : 'Add'} Destination
                            </Button>
                        </div>
                    </Form>
                </Modal.Body>
            </Modal>
        </div>
    );
};

export default DestinationManagement;
