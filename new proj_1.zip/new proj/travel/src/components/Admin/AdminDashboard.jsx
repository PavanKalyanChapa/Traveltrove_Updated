import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Nav, Tab, Alert } from 'react-bootstrap';
import DestinationManagement from './DestinationManagement';
import ItineraryManagement from './ItineraryManagement';
import ReviewManagement from './ReviewManagement';
import './AdminDashboard.css';
 
const AdminDashboard = () => {
    const [user, setUser] = useState(null);
    const [error, setError] = useState('');
 
    useEffect(() => {
        // Check if user is admin
        const token = localStorage.getItem('token');
        const userData = localStorage.getItem('userObj');
 
        if (!token || !userData) {
            setError('Please log in to access admin dashboard');
            return;
        }
 
        const parsedUser = JSON.parse(userData);
        if (parsedUser.role !== 'admin') {
            setError('Access denied. Administrator privileges required.');
            return;
        }
 
        setUser(parsedUser);
    }, []);
 
    if (error) {
        return (
            <Container className="mt-4">
                <Alert variant="danger">
                    <h4>Access Denied</h4>
                    <p>{error}</p>
                </Alert>
            </Container>
        );
    }
 
    if (!user) {
        return (
            <Container className="mt-4">
                <div className="text-center">
                    <div className="spinner-border" role="status">
                        <span className="visually-hidden">Loading...</span>
                    </div>
                </div>
            </Container>
        );
    }
 
    return (
        <Container fluid className="admin-dashboard">
            <Row>
                <Col xs={12}>
                    <div className="admin-header">
                        <h1 className="mb-4">
                            <i className="bi bi-shield-check"></i>Admin Dashboard
                        </h1>
                        <p className="text-white">Welcome, {user.name}! Manage destinations, itineraries, and reviews.</p>
                    </div>
                </Col>
            </Row>
 
            <Tab.Container defaultActiveKey="destinations">
                <Row>
                    <Col sm={3}>
                        <Nav variant="pills" className="flex-column admin-nav">
                            <Nav.Item>
                                <Nav.Link eventKey="destinations">
                                    <i className="bi bi-geo-alt"></i> Destinations
                                </Nav.Link>
                            </Nav.Item>
                            <Nav.Item>
                                <Nav.Link eventKey="itineraries">
                                    <i className="bi bi-map"></i> Itineraries
                                </Nav.Link>
                            </Nav.Item>
                            <Nav.Item>
                                <Nav.Link eventKey="reviews">
                                    <i className="bi bi-star"></i> Reviews
                                </Nav.Link>
                            </Nav.Item>
                        </Nav>
                    </Col>
                    <Col sm={9}>
                        <Tab.Content>
                            <Tab.Pane eventKey="destinations">
                                <DestinationManagement />
                            </Tab.Pane>
                            <Tab.Pane eventKey="itineraries">
                                <ItineraryManagement />
                            </Tab.Pane>
                            <Tab.Pane eventKey="reviews">
                                <ReviewManagement />
                            </Tab.Pane>
                        </Tab.Content>
                    </Col>
                </Row>
            </Tab.Container>
        </Container>
    );
};
 
export default AdminDashboard;
 