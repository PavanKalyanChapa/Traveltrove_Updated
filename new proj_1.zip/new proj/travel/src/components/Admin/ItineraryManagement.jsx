import React, { useState, useEffect } from 'react';
import { Table, Button, Modal, Form, Alert, Badge, Spinner } from 'react-bootstrap';
import axios from 'axios';

const positiveColor = '#F1A501';
const negativeColor = '#DF6951';

const ItineraryManagement = () => {
    const [itineraries, setItineraries] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const [showModal, setShowModal] = useState(false);
    const [editingItinerary, setEditingItinerary] = useState(null);
    const [viewModal, setViewModal] = useState(false);
    const [formData, setFormData] = useState({
        destination: '',
        duration: '',
        activities: '',
        lodging: '',
        dining: ''
    });

    useEffect(() => {
        fetchItineraries();
    }, []);

    const fetchItineraries = async () => {
        try {
            setLoading(true);
            const token = localStorage.getItem('token');
            const response = await axios.get('http://localhost:5000/admin/itineraries', {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            setItineraries(response.data.itineraries || []);
            setError('');
        } catch (err) {
            setError('Failed to fetch itineraries');
            console.error('Error fetching itineraries:', err);
        } finally {
            setLoading(false);
        }
    };

    const handleInputChange = (e) => {
        const { name, value } = e.target;
        setFormData(prev => ({
            ...prev,
            [name]: value
        }));
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        const token = localStorage.getItem('token');

        if (!token) {
            setError('Authentication required');
            return;
        }

        try {
            const processedData = {
                ...formData,
                activities: formData.activities ? formData.activities.split(',').map(item => item.trim()) : []
            };

            if (editingItinerary) {
                await axios.put(
                    `http://localhost:5000/admin/itineraries/${editingItinerary.id}`,
                    processedData,
                    {
                        headers: {
                            'Authorization': `Bearer ${token}`
                        }
                    }
                );
                setSuccess('Itinerary updated successfully');
            }

            setShowModal(false);
            setEditingItinerary(null);
            resetForm();
            fetchItineraries();
        } catch (err) {
            setError(err.response?.data?.error || 'Failed to save itinerary');
            console.error('Error saving itinerary:', err);
        }
    };

    const handleEdit = (itinerary) => {
        setEditingItinerary(itinerary);
        setFormData({
            destination: itinerary.destination || '',
            duration: itinerary.duration || '',
            activities: itinerary.activities ? itinerary.activities.join(', ') : '',
            lodging: itinerary.lodging || '',
            dining: itinerary.dining || ''
        });
        setShowModal(true);
    };

    const handleView = (itinerary) => {
        setEditingItinerary(itinerary);
        setFormData({
            destination: itinerary.destination || '',
            duration: itinerary.duration || '',
            activities: itinerary.activities ? itinerary.activities.join(', ') : '',
            lodging: itinerary.lodging || '',
            dining: itinerary.dining || ''
        });
        setViewModal(true);
    };

    const handleDelete = async (itineraryId) => {
        if (!window.confirm('Are you sure you want to delete this itinerary?')) return;

        const token = localStorage.getItem('token');

        try {
            await axios.delete(
                `http://localhost:5000/admin/itineraries/${itineraryId}`,
                {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                }
            );
            setSuccess('Itinerary deleted successfully');
            fetchItineraries();
        } catch (err) {
            setError(err.response?.data?.error || 'Failed to delete itinerary');
            console.error('Error deleting itinerary:', err);
        }
    };

    const resetForm = () => {
        setFormData({
            destination: '',
            duration: '',
            activities: '',
            lodging: '',
            dining: ''
        });
    };

    if (loading) {
        return (
            <div className="loading-spinner">
                <Spinner animation="border" role="status" style={{ color: positiveColor }}>
                    <span className="visually-hidden">Loading...</span>
                </Spinner>
                <p className="mt-2" style={{ color: positiveColor }}>Loading itineraries...</p>
            </div>
        );
    }

    return (
        <div className="management-section">
            <h2 style={{ color: positiveColor }}>Itinerary Management</h2>

            {error && (
                <Alert variant="danger" onClose={() => setError('')} dismissible>
                    {error}
                </Alert>
            )}

            {success && (
                <Alert variant="success" onClose={() => setSuccess('')} dismissible>
                    {success}
                </Alert>
            )}

            {itineraries.length === 0 ? (
                <div className="empty-state">
                    <i className="bi bi-map" style={{ color: positiveColor }}></i>
                    <h4 style={{ color: positiveColor }}>No itineraries found</h4>
                    <p style={{ color: positiveColor }}>Users haven't created any itineraries yet.</p>
                </div>
            ) : (
                <Table responsive className="data-table">
                    <thead>
                        <tr style={{ color: positiveColor }}>
                            <th>ID</th>
                            <th>Destination</th>
                            <th>Duration</th>
                            <th>User ID</th>
                            <th>Activities</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        {itineraries.map((itinerary) => (
                            <tr key={itinerary.id}>
                                <td>{itinerary.id}</td>
                                <td>{itinerary.destination}</td>
                                <td>{itinerary.duration || 'N/A'}</td>
                                <td>{itinerary.userId}</td>
                                <td>
                                    {itinerary.activities && itinerary.activities.length > 0 ? (
                                        <Badge className="custom-badge me-2">
                                            {itinerary.activities.length} activities
                                        </Badge>
                                    ) : (
                                        <span className="text-muted">No activities</span>
                                    )}
                                </td>
                                <td>
                                    <Button
                                        style={{ backgroundColor: positiveColor, border: 'none', color: 'white', fontWeight: 600, marginRight: 5 }}
                                        onClick={() => handleView(itinerary)}
                                    >
                                        View
                                    </Button>

                                    <Button
                                        style={{ backgroundColor: positiveColor, border: 'none', color: 'white', fontWeight: 600, marginRight: 5 }}
                                        onClick={() => handleEdit(itinerary)}
                                    >
                                        Edit
                                    </Button>

                                    <Button
                                        style={{ backgroundColor: negativeColor, border: 'none', color: 'white', fontWeight: 600 }}
                                        onClick={() => handleDelete(itinerary.id)}
                                    >
                                        Delete
                                    </Button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </Table>
            )}

            {/* Edit Modal */}
            <Modal show={showModal} onHide={() => setShowModal(false)} size="lg">
                <Modal.Header closeButton>
                    <Modal.Title>Edit Itinerary</Modal.Title>
                </Modal.Header>
                <Modal.Body>
                    <Form onSubmit={handleSubmit}>
                        <Form.Group className="mb-3">
                            <Form.Label>Destination</Form.Label>
                            <Form.Control
                                type="text"
                                name="destination"
                                value={formData.destination}
                                onChange={handleInputChange}
                            />
                        </Form.Group>

                        <Form.Group className="mb-3">
                            <Form.Label>Duration</Form.Label>
                            <Form.Control
                                type="text"
                                name="duration"
                                value={formData.duration}
                                onChange={handleInputChange}
                                placeholder="e.g., 5 days"
                            />
                        </Form.Group>

                        <Form.Group className="mb-3">
                            <Form.Label>Activities (comma-separated)</Form.Label>
                            <Form.Control
                                as="textarea"
                                rows={3}
                                name="activities"
                                value={formData.activities}
                                onChange={handleInputChange}
                                placeholder="Activity 1, Activity 2, Activity 3"
                            />
                        </Form.Group>

                        <Form.Group className="mb-3">
                            <Form.Label>Lodging</Form.Label>
                            <Form.Control
                                as="textarea"
                                rows={2}
                                name="lodging"
                                value={formData.lodging}
                                onChange={handleInputChange}
                            />
                        </Form.Group>

                        <Form.Group className="mb-3">
                            <Form.Label>Dining</Form.Label>
                            <Form.Control
                                as="textarea"
                                rows={2}
                                name="dining"
                                value={formData.dining}
                                onChange={handleInputChange}
                            />
                        </Form.Group>

                        <div className="d-flex justify-content-end">
                            <Button
                                variant="secondary"
                                onClick={() => setShowModal(false)}
                                style={{ backgroundColor: negativeColor, border: 'none' }}
                            >
                                Cancel
                            </Button>

                            <Button
                                type="submit"
                                style={{ backgroundColor: positiveColor, border: 'none', color: 'white', fontWeight: 600 }}
                            >
                                Update Itinerary
                            </Button>
                        </div>
                    </Form>
                </Modal.Body>
            </Modal>

            {/* ✅ View Modal Styled Like Review Modal */}
            <Modal show={viewModal} onHide={() => setViewModal(false)} size="lg">
                <Modal.Header closeButton style={{ backgroundColor: positiveColor }}>
                    <Modal.Title style={{ color: 'white' }}>Itinerary Details</Modal.Title>
                </Modal.Header>

                <Modal.Body style={{ color: '#000' }}>
                    {editingItinerary && (
                        <div>
                            <div className="row mb-3">
                                <div className="col-md-6">
                                    <strong>Destination:</strong> {editingItinerary.destination}
                                </div>
                                <div className="col-md-6">
                                    <strong>Duration:</strong> {editingItinerary.duration || 'N/A'}
                                </div>
                            </div>

                            <div className="row mb-3">
                                <div className="col-md-6">
                                    <strong>Lodging:</strong> {editingItinerary.lodging}
                                </div>
                                <div className="col-md-6">
                                    <strong>Dining:</strong> {editingItinerary.dining}
                                </div>
                            </div>

                            <div className="mb-3">
                                <strong>Activities:</strong>
                                <div className="mt-2">
                                    {editingItinerary.activities && editingItinerary.activities.length > 0 ? (
                                        editingItinerary.activities.map((activity, index) => (
                                            <Badge key={index} className="custom-badge me-2">
                                                {activity}
                                            </Badge>
                                        ))
                                    ) : (
                                        <span className="text-muted">No activities</span>
                                    )}
                                </div>
                            </div>

                            <div className="mb-3">
                                <strong>Itinerary ID:</strong> {editingItinerary.id}
                            </div>

                            <div className="mb-3">
                                <strong>User ID:</strong> {editingItinerary.userId}
                            </div>
                        </div>
                    )}
                </Modal.Body>

                <Modal.Footer>
                    <Button
                        style={{ backgroundColor: positiveColor, border: 'none', color: 'white', fontWeight: 600 }}
                        onClick={() => setViewModal(false)}
                    >
                        Close
                    </Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
};

export default ItineraryManagement;
