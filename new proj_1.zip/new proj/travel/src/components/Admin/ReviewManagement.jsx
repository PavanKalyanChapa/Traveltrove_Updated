import React, { useState, useEffect } from 'react';
import { Table, Button, Alert, Badge, Spinner, Modal } from 'react-bootstrap';
import axios from 'axios';
import './AdminDashboard.css';

const positiveColor = '#F1A501';
const negativeColor = '#DF6951';

const ReviewManagement = () => {
    const [reviews, setReviews] = useState([]);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState('');
    const [showModal, setShowModal] = useState(false);
    const [selectedReview, setSelectedReview] = useState(null);

    useEffect(() => {
        fetchReviews();
    }, []);

    const fetchReviews = async () => {
        try {
            setLoading(true);
            const token = localStorage.getItem('token');
            const response = await axios.get('http://localhost:5000/admin/reviews', {
                headers: {
                    'Authorization': `Bearer ${token}`
                }
            });
            setReviews(response.data.reviews || []);
            setError('');
        } catch (err) {
            setError('Failed to fetch reviews');
            console.error('Error fetching reviews:', err);
        } finally {
            setLoading(false);
        }
    };

    const handleDelete = async (reviewId) => {
        if (!window.confirm('Are you sure you want to delete this review?')) {
            return;
        }

        const token = localStorage.getItem('token');

        try {
            await axios.delete(
                `http://localhost:5000/admin/reviews/${reviewId}`,
                {
                    headers: {
                        'Authorization': `Bearer ${token}`
                    }
                }
            );
            setSuccess('Review deleted successfully');
            fetchReviews();
        } catch (err) {
            setError(err.response?.data?.error || 'Failed to delete review');
            console.error('Error deleting review:', err);
        }
    };

    const handleViewDetails = (review) => {
        setSelectedReview(review);
        setShowModal(true);
    };

    const formatDate = (dateString) => {
        return new Date(dateString).toLocaleDateString('en-US', {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
        });
    };

    if (loading) {
        return (
            <div className="loading-spinner">
                <Spinner animation="border" role="status" style={{ color: positiveColor }}>
                    <span className="visually-hidden">Loading...</span>
                </Spinner>
                <p className="mt-2" style={{ color: positiveColor }}>Loading reviews...</p>
            </div>
        );
    }

    return (
        <div className="management-section">
            <h2 style={{ color: positiveColor }}>Review Management</h2>

            {error && (
                <Alert variant="danger" onClose={() => setError('')} dismissible>
                    <span style={{ color: negativeColor }}>{error}</span>
                </Alert>
            )}

            {success && (
                <Alert variant="success" onClose={() => setSuccess('')} dismissible>
                    <span style={{ color: positiveColor }}>{success}</span>
                </Alert>
            )}

            {reviews.length === 0 ? (
                <div className="empty-state">
                    <i className="bi bi-star" style={{ color: positiveColor }}></i>
                    <h4 style={{ color: positiveColor }}>No reviews found</h4>
                    <p style={{ color: positiveColor }}>Users haven't submitted any reviews yet.</p>
                </div>
            ) : (
                <>
                    <div className="mb-3">
                        <Badge className="custom-badge me-2">
                            Total Reviews: {reviews.length}
                        </Badge>

                        <Badge className="custom-badge me-2">
                            Avg Rating: {(reviews.reduce((sum, review) => sum + review.rating, 0) / reviews.length).toFixed(1)}
                        </Badge>
                    </div>

                    <Table responsive className="data-table">
                        <thead>
                            <tr style={{ }}>
                                <th>Type</th>
                                <th>User</th>
                                <th>Rating</th>
                                <th>Comment</th>
                                <th>Date</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            {reviews.map((review) => (
                                <tr key={review._id}>
                                    <td>
                                            {review.type === 'destination-guide' ? 'Destination' : 'Itinerary'}
                                    </td>
                                    <td>{review.user}</td>
                                    <td>
                                            <i className="bi bi-star-fill"></i> {review.rating}/5
                                    </td>
                                    <td>
                                        <div style={{ maxWidth: '200px', overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap', color: '#000' }}>
                                            {review.comment}
                                        </div>
                                    </td>
                                    <td style={{ color: '#000' }}>{formatDate(review.createdAt)}</td>
                                    <td>
                                        <Button
                                            variant="outline-info"
                                            size="sm"
                                            className="btn-sm-admin"
                                            style={{
                                                backgroundColor: positiveColor,
                                                borderColor: positiveColor,
                                                color: 'white'
                                            }}
                                            onClick={() => handleViewDetails(review)}
                                        >
                                            <i className="bi bi-eye"></i> View
                                        </Button>
                                        <Button
                                            variant="outline-danger"
                                            size="sm"
                                            className="btn-sm-admin"
                                            style={{
                                                backgroundColor: negativeColor,
                                                borderColor: negativeColor,
                                                color: 'white'
                                            }}
                                            onClick={() => handleDelete(review._id)}
                                        >
                                            <i className="bi bi-trash"></i> Delete
                                        </Button>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </Table>
                </>
            )}

            {/* Review Details Modal */}
            <Modal show={showModal} onHide={() => setShowModal(false)} size="lg">
                <Modal.Header closeButton style={{ backgroundColor: positiveColor }}>
                    <Modal.Title style={{ color: 'white' }}>Review Details</Modal.Title>
                </Modal.Header>
                <Modal.Body style={{ color: '#000' }}>
                    {selectedReview && (
                        <div>
                            <div className="row mb-3">
                                <div className="col-md-6">
                                    <strong>Type: </strong>
                                    <Badge className="custom-badge me-2">
                                        {selectedReview.type === 'destination-guide' ? 'Destination Guide' : 'Trip Itinerary'}
                                    </Badge>
                                </div>
                                <div className="col-md-6">
                                    <strong>Rating: </strong>
                                    <Badge className="custom-badge me-2">
                                        <i className="bi bi-star-fill"></i> {selectedReview.rating}/5
                                    </Badge>
                                </div>
                            </div>

                            <div className="row mb-3">
                                <div className="col-md-6">
                                    <strong>User:</strong> {selectedReview.user}
                                </div>
                                <div className="col-md-6">
                                    <strong>Date:</strong> {formatDate(selectedReview.createdAt)}
                                </div>
                            </div>

                            <div className="mb-3">
                                <strong>Comment:</strong>
                                <div className="mt-2 p-3" style={{ backgroundColor: '#f8f9fa', color: positiveColor, borderRadius: '5px' }}>
                                    {selectedReview.comment}
                                </div>
                            </div>

                            {selectedReview.activities && selectedReview.activities.length > 0 && (
                                <div className="mb-3">
                                    <strong>Related Activities:</strong>
                                    <div className="mt-2">
                                        {selectedReview.activities.map((activity, index) => (
                                            <Badge key={index} className="custom-badge me-2">
                                                {activity}
                                            </Badge>
                                        ))}
                                    </div>
                                </div>
                            )}

                            <div className="mb-3">
                                <strong>Review ID:</strong> {selectedReview._id}
                            </div>

                            <div className="mb-3">
                                <strong>Target ID:</strong> {selectedReview.id}
                            </div>
                        </div>
                    )}
                </Modal.Body>
                <Modal.Footer>
                    <Button variant="" onClick={() => setShowModal(false)} style={{ backgroundColor: positiveColor, color: "white" }}>
                        Close
                    </Button>
                    <Button
                        variant="danger"
                        style={{ borderColor: negativeColor, color: "white" }}
                        onClick={() => {
                            setShowModal(false);
                            handleDelete(selectedReview._id);
                        }}
                    >
                        <i className="bi bi-trash"></i> Delete Review
                    </Button>
                </Modal.Footer>
            </Modal>
        </div>
    );
};

export default ReviewManagement;
