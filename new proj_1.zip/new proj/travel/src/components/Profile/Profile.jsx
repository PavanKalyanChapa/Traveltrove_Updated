import React from 'react';
import { useAuth } from '../../contexts/AuthContext';
import { FaUser, FaIdCard, FaEnvelope, FaPhone } from 'react-icons/fa';

const Profile = () => {
    const { userObj } = useAuth();

    if (!userObj) {
        return (
            <div className="container mt-5">
                <div className="row justify-content-center">
                    <div className="col-md-6 text-center">
                        <div className="alert alert-warning">
                            <h4>No User Data</h4>
                            <p>Please log in to view your profile.</p>
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="container mt-5">
            <div className="row justify-content-center">
                <div className="col-md-8 col-lg-6">
                    <div className="card shadow-lg border-0" style={{ borderRadius: '15px' }}>
                        {/* Header */}
                        <div 
                            className="card-header text-center text-white py-4" 
                            style={{ 
                                background: 'linear-gradient(135deg, #e09401 0%, #DF6951 100%)',
                                borderRadius: '15px 15px 0 0'
                            }}
                        >
                            <div className="mb-3">
                                <FaUser 
                                    style={{ 
                                        fontSize: '4rem', 
                                        backgroundColor: 'rgba(255,255,255,0.2)', 
                                        padding: '20px', 
                                        borderRadius: '50%' 
                                    }} 
                                />
                            </div>
                            <h2 className="mb-0" style={{ fontWeight: '700' }}>My Profile</h2>
                            <p className="mb-0 opacity-75">Welcome to TravelTrove</p>
                        </div>

                        {/* Profile Content */}
                        <div className="card-body p-4">
                            <div className="row g-4">
                                {/* User ID */}
                                <div className="col-12">
                                    <div className="d-flex align-items-center p-3 bg-light rounded-3">
                                        <FaIdCard 
                                            className="text-primary me-3" 
                                            style={{ fontSize: '1.5rem' }} 
                                        />
                                        <div>
                                            <h6 className="mb-1 text-muted">User ID</h6>
                                            <p className="mb-0 fw-bold" style={{ fontSize: '1.1rem' }}>
                                                {userObj.userId}
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                {/* Name */}
                                <div className="col-12">
                                    <div className="d-flex align-items-center p-3 bg-light rounded-3">
                                        <FaUser 
                                            className="text-success me-3" 
                                            style={{ fontSize: '1.5rem' }} 
                                        />
                                        <div>
                                            <h6 className="mb-1 text-muted">Full Name</h6>
                                            <p className="mb-0 fw-bold" style={{ fontSize: '1.1rem' }}>
                                                {userObj.name}
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                {/* Email (if available) */}
                                {userObj.email && (
                                    <div className="col-12">
                                        <div className="d-flex align-items-center p-3 bg-light rounded-3">
                                            <FaEnvelope 
                                                className="text-info me-3" 
                                                style={{ fontSize: '1.5rem' }} 
                                            />
                                            <div>
                                                <h6 className="mb-1 text-muted">Email</h6>
                                                <p className="mb-0 fw-bold" style={{ fontSize: '1.1rem' }}>
                                                    {userObj.email}
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                )}

                                {/* Phone (if available) */}
                                {userObj.phoneNumber && (
                                    <div className="col-12">
                                        <div className="d-flex align-items-center p-3 bg-light rounded-3">
                                            <FaPhone 
                                                className="text-warning me-3" 
                                                style={{ fontSize: '1.5rem' }} 
                                            />
                                            <div>
                                                <h6 className="mb-1 text-muted">Phone Number</h6>
                                                <p className="mb-0 fw-bold" style={{ fontSize: '1.1rem' }}>
                                                    {userObj.phoneNumber}
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                )}

                                {/* Role (if available) */}
                                {userObj.role && (
                                    <div className="col-12">
                                        <div className="d-flex align-items-center p-3 bg-light rounded-3">
                                            <div 
                                                className="me-3 d-flex align-items-center justify-content-center"
                                                style={{ 
                                                    width: '24px', 
                                                    height: '24px', 
                                                    fontSize: '1.5rem' 
                                                }}
                                            >
                                                👤
                                            </div>
                                            <div>
                                                <h6 className="mb-1 text-muted">Role</h6>
                                                <p className="mb-0 fw-bold" style={{ fontSize: '1.1rem' }}>
                                                    <span 
                                                        className={`badge ${userObj.role === 'admin' ? 'bg-danger' : 'bg-primary'}`}
                                                        style={{ fontSize: '0.9rem' }}
                                                    >
                                                        {userObj.role.charAt(0).toUpperCase() + userObj.role.slice(1)}
                                                    </span>
                                                </p>
                                            </div>
                                        </div>
                                    </div>
                                )}
                            </div>

                            {/* Footer */}
                            <div className="text-center mt-4 pt-3 border-top">
                                <p className="text-muted mb-0">
                                    <small>Member since you joined TravelTrove</small>
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Profile;
