import { Navigate } from "react-router-dom";
import { useAuth } from "../contexts/AuthContext";
 
function ProtectedRoute({ children }) {
 const { token,loading} = useAuth();
 

 if(loading){
  return <div>Loading ...</div>
 }
 if (!token) {
    //  alert("login to Proceed");
   return <Navigate to="/" replace/>; // redirect to Home if not logged in
 }
 
 return children;
}
 
export default ProtectedRoute;
