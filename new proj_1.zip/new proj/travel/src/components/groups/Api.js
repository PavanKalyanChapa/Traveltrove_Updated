import axios from "axios";
 
const API = axios.create({
    baseURL: "http://localhost:5000/api/auth"
});
 
// Add token to requests if available
API.interceptors.request.use((config) => {
    const token = localStorage.getItem('token');
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
});
 
// Groups API - Enhanced for User Story 6
export const fetchGroups = () => API.get("/groups");
export const createGroup = (data) => API.post("/groups", data);
export const joinGroup = (groupId) => API.post(`/groups/${groupId}/join`);
export const leaveGroup = (groupId) => API.post(`/groups/${groupId}/leave`);
export const getGroupDetails = () => API.get(`/my-groups`);
 