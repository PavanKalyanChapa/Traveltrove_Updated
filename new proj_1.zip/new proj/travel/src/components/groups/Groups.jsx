import "bootstrap/dist/css/bootstrap.min.css";
import React, { useState, useEffect } from "react";
import { fetchGroups, joinGroup, createGroup, getGroupDetails, leaveGroup } from "./Api";
import { Modal, Alert, Badge, Tabs, Tab } from "react-bootstrap";
import { PlusCircle } from "react-bootstrap-icons";
import './Groups.css';
import { useAuth } from '../../contexts/AuthContext';
import { useNavigate } from 'react-router-dom';

const Groups = () => {
    const { userObj, isAuthenticated } = useAuth();
    const navigate = useNavigate();
    const [groups, setGroups] = useState([]);
    const [myGroups, setMyGroups] = useState([]);
    const [newGroup, setNewGroup] = useState({
        groupName: "",
        description: ""
    });
    const [showModal, setShowModal] = useState(false);
    const [alert, setAlert] = useState({ show: false, message: "", type: "" });
    const [activeTab, setActiveTab] = useState("groups");

    const showAlert = (message, type = "info") => {
        setAlert({ show: true, message, type });
        setTimeout(() => setAlert({ show: false, message: "", type: "" }), 5000);
    };

    useEffect(() => {
        if (isAuthenticated && userObj) {
            loadMyGroups();
        }
    }, [isAuthenticated, userObj]);

    useEffect(() => {
        if (isAuthenticated) {
            loadGroups();
        } else {
            fetchGroups()
                .then(res => setGroups(res.data))
                .catch(() => showAlert("Failed to load groups", "danger"));
        }
    }, [myGroups, isAuthenticated]);

    const loadMyGroups = async () => {
        try {
            const res = await getGroupDetails();
            setMyGroups(res.data);
        } catch (err) {
            console.log("Failed to load my groups", err);
            showAlert("Failed to load joined groups", "danger");
        }
    };

    const loadGroups = async () => {
        try {
            const res = await fetchGroups();
            let allGroups = res.data;

            if (myGroups.length > 0) {
                const myGroupIds = new Set(myGroups.map(g => g.groupId));
                allGroups = allGroups.map(g => ({
                    ...g,
                    isMember: myGroupIds.has(g.groupId),
                }));
            } else {
                allGroups = allGroups.map(g => ({ ...g, isMember: false }));
            }

            setGroups(allGroups);
        } catch (err) {
            console.log("Error fetching groups:", err);
            showAlert("Failed to load groups", "danger");
        }
    };

    const handleJoinGroup = async (groupId) => {
        if (!isAuthenticated) {
            navigate('/login');
            return;
        }

        try {
            const res = await joinGroup(groupId);
            showAlert(`Successfully joined ${res.data.group.groupName}!`, "success");
            await loadMyGroups();
            await loadGroups();
        } catch (err) {
            console.log("Error joining group:", err);
            if (err.response?.status === 409) {
                showAlert("You are already a member of this group", "info");
            } else {
                showAlert("Failed to join group", "danger");
            }
        }
    };

    const handleLeaveGroup = async (groupId) => {
        try {
            await leaveGroup(groupId);
            showAlert("You have left the group", "success");
            await loadMyGroups();
            await loadGroups();
        } catch (err) {
            console.error("Failed to leave group", err);
            if (err.response?.status === 409) {
                showAlert("You are not a member of this group", "info");
            } else {
                showAlert("Failed to leave group", "danger");
            }
        }
    };

    const handleCreateGroup = async () => {
        if (!isAuthenticated) {
            navigate('/login');
            return;
        }

        try {
            const res = await createGroup(newGroup);
            showAlert(`${newGroup.groupName} group created successfully!`, "success");
            await loadMyGroups();
            await loadGroups();
            setNewGroup({ groupName: "", description: "" });
            setShowModal(false);
        } catch (err) {
            console.log("Failed to create group", err);
            if (err.response?.status === 409) {
                showAlert("A group with this name already exists", "warning");
            } else {
                showAlert("Failed to create group", "danger");
            }
        }
    };

    const getInitials = (name) => {
        if (!name || typeof name !== 'string' || name.length === 0) {
            return "GR";
        }
        const words = name.trim().split(" ");
        if (words.length === 1) {
            return words[0].slice(0, 2).toUpperCase();
        } else {
            return (words[0][0] + words[1][0]).toUpperCase();
        }
    };

    const getColorFromName = (name) => {
        const colors = ["#F1A501", "#DF6951", "#181E4B", "#5E6282", "#14183E"];
        if (!name || typeof name !== 'string' || name.length === 0) {
            return colors[0];
        }
        const index = name.charCodeAt(0) % colors.length;
        return colors[index];
    };

    return (
        <>
            <div className="groups-container">
                <div className="category-title">
                    <h3>Travel Groups</h3>
                    <h5>Connect with fellow travelers and plan group adventures</h5>
                </div>
            </div>

            {alert.show && (
                <Alert variant={alert.type} className="custom-alert mx-3" dismissible onClose={() => setAlert({ show: false, message: "", type: "" })}>
                    {alert.message}
                </Alert>
            )}

            <div className="container mt-4">
                <Tabs activeKey={activeTab} onSelect={(k) => setActiveTab(k)} className="custom-tabs mb-4">
                    <Tab eventKey="groups" title="Groups">
                        <div className="d-flex justify-content-between align-items-center mb-4">
                            <h4 className="section-heading">Available Groups</h4>
                            {isAuthenticated && (
                                <button className="create-group-btn" onClick={() => setShowModal(true)}>
                                    <PlusCircle className="me-2" />
                                    Create Group
                                </button>
                            )}
                        </div>

                        <div className="group-cards-container">
                            {groups.map((group) => (
                                <div key={group.groupId} className="group-card">
                                    <div className="card-body">
                                        <div className="group-header">
                                            <div className="group-avatar" style={{ backgroundColor: getColorFromName(group.groupName) }}>
                                                {getInitials(group.groupName)}
                                            </div>
                                            <div className="group-info">
                                                <h5 className="group-title">{group.groupName}</h5>
                                                <small className="group-members">{group.members.length} members</small>
                                            </div>
                                        </div>

                                        <p className="group-description">{group.description}</p>

                                        <div className="group-actions">
                                            {group.isMember ? (
                                                <Badge className="joined-badge">Joined Group Successfully</Badge>
                                            ) : (
                                                <button className="join-btn" onClick={() => handleJoinGroup(group.groupId)}>
                                                    {!isAuthenticated ? "Login to Join" : "Join Group"}
                                                </button>
                                            )}
                                        </div>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </Tab>

                    {isAuthenticated && (
                        <Tab eventKey="mygroups" title="My Groups">
                            <div className="d-flex justify-content-between align-items-center mb-4">
                                <h4 className="section-heading">Joined Groups</h4>
                            </div>
                            <div className="group-cards-container">
                                {myGroups.length > 0 ? (
                                    myGroups.map((group) => (
                                        <div key={group.groupId} className="group-card">
                                            <div className="card-body">
                                                <div className="group-header">
                                                    <div className="group-avatar" style={{ backgroundColor: getColorFromName(group.groupName) }}>
                                                        {getInitials(group.groupName)}
                                                    </div>
                                                    <div className="group-info">
                                                        <h5 className="group-title">{group.groupName}</h5>
                                                        <small className="group-members">{group.members.length} members</small>
                                                    </div>
                                                </div>

                                                <p className="group-description">{group.description}</p>

                                                <div className="group-actions">
                                                    <button className="leave-btn" onClick={() => handleLeaveGroup(group.groupId)}>
                                                        Leave Group
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    ))
                                ) : (
                                    <p className="no-groups-text">You haven't joined any groups yet.</p>
                                )}
                            </div>
                        </Tab>
                    )}
                </Tabs>
            </div>

            {/* Create Group Modal */}
            <Modal show={showModal} onHide={() => setShowModal(false)} className="custom-modal">
                <Modal.Header closeButton className="custom-modal-header">
                    <Modal.Title>Create New Group</Modal.Title>
                </Modal.Header>
                <Modal.Body className="custom-modal-body">
                    <form>
                        <div className="mb-3">
                            <label htmlFor="groupname" className="form-label">Group Name</label>
                            <input
                                type="text"
                                name="groupname"
                                id="groupname"
                                className="form-control"
                                value={newGroup.groupName}
                                onChange={(e) => setNewGroup({ ...newGroup, groupName: e.target.value })}
                                required
                            />
                        </div>
                        <div className="mb-3">
                            <label htmlFor="description" className="form-label">Description</label>
                            <textarea
                                name="description"
                                id="description"
                                rows="3"
                                className="form-control"
                                value={newGroup.description}
                                onChange={(e) => setNewGroup({ ...newGroup, description: e.target.value })}
                                required
                            />
                        </div>
                    </form>
                </Modal.Body>
                <Modal.Footer className="custom-modal-footer">
                    <button className="cancel-btn" onClick={() => setShowModal(false)}>Cancel</button>
                    <button className="create-btn" onClick={handleCreateGroup}>
                        Create Group
                    </button>
                </Modal.Footer>
            </Modal>
        </>
    );
};

export default Groups;
