import { Link } from "react-router-dom";
import { useState } from "react";
import { useAuth } from '../../contexts/AuthContext';
import { useNavigate } from "react-router-dom";

const Navbar = () => {
    const [isOpen, setIsOpen] = useState(false);
    const [dropdownOpen, setDropdownOpen] = useState(false);
    const { isAuthenticated, logout, userObj } = useAuth();
    const navigate = useNavigate();

    const handleLogout = () => {
        logout();
        navigate("/");
    };

    return (
        <header className="header">
            {/* Logo */}
            <Link to="/" className="d-flex align-items-center">
                <img src="./logo.svg" width={'200px'} alt="Logo" />
            </Link>

            {/* Navbar */}
            <nav className="navbar">
                <ul className={isOpen ? "show" : ""}>
                    <li><Link to="/destinations" onClick={() => setIsOpen(false)}>Destinations</Link></li>
                    <li><Link to="/groups" onClick={() => setIsOpen(false)}>Groups</Link></li>
                    <li><Link to="/reviews" onClick={() => setIsOpen(false)}>Reviews</Link></li>

                    {isAuthenticated && (
                        <>
                            <li><Link to="/favorites" onClick={() => setIsOpen(false)}>Favorites</Link></li>
                            <li><Link to="/itineraries" onClick={() => setIsOpen(false)}>Itineraries</Link></li>
                            {userObj?.role === "admin" && (
                                <li><Link to="/admin"  onClick={() => setIsOpen(false)}>Admin Dashboard</Link></li>
                            )}

                            {/* User Dropdown */}
                            <li className="dropdown">
                                <button
                                    className="btn"
                                    type="button"
                                    style={{
                                        backgroundColor: "#F1A501",
                                        color: "#ffffff",
                                        border: "none",
                                        borderRadius: "6px",
                                        padding: "6px 14px",
                                        fontWeight: "bold",
                                    }}
                                    onClick={() => setDropdownOpen(!dropdownOpen)}
                                >
                                    {userObj.name[0].toUpperCase()+userObj.name.slice(1)} ▼
                                </button>

                                {dropdownOpen && (
                                    <ul className="dropdown-menu show">
                                        <li>
                                            <Link
                                                to="/profile"
                                                className="dropdown-item"
                                                onClick={() => {
                                                    setIsOpen(false);
                                                    setDropdownOpen(false);
                                                }}
                                                style={{marginTop:"0.5rem"}}
                                            >
                                                Profile
                                            </Link>
                                        </li>
                                        <li><hr className="dropdown-divider" /></li>
                                        <li>
                                            <button
                                                className="dropdown-item"
                                                style={{
                                                    backgroundColor: "#DF6951",
                                                    color: "#ffffff",
                                                    border: "none",
                                                    marginBottom:"0.5rem"
                                                }}
                                                onClick={() => {
                                                    handleLogout();
                                                    setDropdownOpen(false);
                                                }}
                                            >
                                                Logout
                                            </button>
                                        </li>
                                    </ul>
                                )}
                            </li>
                        </>
                    )}

                    {!isAuthenticated && (
                        <>
                            <li><Link to="/login" className="login-btn" onClick={() => setIsOpen(false)}>Sign In</Link></li>
                            <li><Link to="/register" className="signup-btn" onClick={() => setIsOpen(false)}>Sign Up</Link></li>
                        </>
                    )}
                </ul>

                {/* Mobile toggle button */}
                <button
                    className={`navbar-toggler ${isOpen ? 'active' : ''}`}
                    onClick={() => setIsOpen(!isOpen)}
                    aria-label="Toggle navigation"
                >
                    <span className="navbar-toggler-icon"></span>
                </button>
            </nav>
        </header>
    );
};

export default Navbar;
