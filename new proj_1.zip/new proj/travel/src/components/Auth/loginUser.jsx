import React, { useState } from "react";
 
import { useNavigate } from "react-router-dom";
 
import axios from "axios";
 
import { useAuth } from '../../contexts/AuthContext';
 
function Login() {
 
    const navigate = useNavigate()
 
    const { login } = useAuth();
 
    const [email, setemail] = useState("");
 
    const [password, setPassword] = useState("");
 
    const [message, setMessage] = useState("");
 
    const handleLogin = async (e) => {
 
        e.preventDefault();
 
        try {
 
            const res = await axios.post("http://localhost:5000/api/auth/login", {
 
                email,
 
                password,
 
            });
 
            console.log(res.data.user);
 
            login(res.data.token, res.data.user); // Use auth context
 
            navigate("/");
 
            setMessage("Login Successful!");
 
        } catch (err) {
 
            setMessage("Invalid credentials!");
 
        }
 
    };
 
    return (
 
        <div className="d-flex justify-content-center align-items-center vh-100 bg-light" style={{ backgroundImage: `url('./bg8.jpg')`, backgroundSize: "cover", backgroundPosition: "center" }}>
 
            <div className="card shadow p-4" style={{ width: "350px", borderRadius: "12px", background: "rgba(255,255,255,0.2)", backdropFilter: "blur(10px)" }}>
 
                <h2 className="text-center fw-bold mb-2">
 
                    <span style={{ color: "#d89001" }}>User</span> Login
 
                </h2>
 
                <p className="text-muted text-center mb-4">
 
                    Enter your credentials to access Your Account
 
                </p>
 
                <form onSubmit={handleLogin}>
 
                    <div className="mb-3 text-start">
 
                        <label htmlFor="email" className="form-label fw-semibold">Email</label>
 
                        <input
 
                            type="email"
 
                            id='email'
 
                            className="form-control"
 
                            placeholder="your email id"
 
                            value={email}
 
                            onChange={(e) => setemail(e.target.value)}
 
                            required
 
                        />
 
                    </div>
 
                    <div className="mb-3 text-start">
 
                        <label htmlFor="password" className="form-label fw-semibold">Password</label>
 
                        <input
 
                            type="password"
 
                            id="password"
 
                            className="form-control"
 
                            placeholder="your password"
 
                            value={password}
 
                            onChange={(e) => setPassword(e.target.value)}
 
                            required
 
                        />
 
                    </div>
 
                    <button type="submit" className="btn btn-primary w-100 fw-semibold" style={{ backgroundColor: "#d89001" }}>
 
                        Login
 
                    </button>
 
                    <p className={` ${message === "Login Successful!" ? "text-success" : "text-danger"}`}>{message}</p>
 
                </form>
 
                <p className="text-center mt-3 text-muted">
 
                    New User ?{" "}
 
                    <a href="/register" className="fw-semibold text-decoration-none" style={{color:"#d89001"}}>
 
                        Register here
 
                    </a>
 
                </p>
 
            </div>
 
        </div>
 
    );
 
}
 
export default Login;