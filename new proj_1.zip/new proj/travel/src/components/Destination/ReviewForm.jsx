import { useState } from "react";
import axios from "axios";
import { FaStar, FaUser, FaComment, FaMapMarkerAlt, FaPaperPlane, FaExclamationTriangle, FaCheckCircle } from "react-icons/fa";
import "./ReviewForm.css";

export default function ReviewForm({ type, id, location,onReviewAdded, token }) {
  const [user, setUser] = useState("");
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState("");
  const [activities, setActivities] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(false);
  const [hoveredRating, setHoveredRating] = useState(0);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    setSuccess(false);

    try {
      await axios.post("http://localhost:5000/reviews", {
        type,
        id,
        location,
        user,
        rating,
        comment,
        activities: activities.split(",").map(a => a.trim()).filter(a => a.length > 0),
      }, {
        headers: {
          Authorization: `Bearer ${token}`
        }
      });

      setUser("");
      setRating(5);
      setComment("");
      setActivities("");
      setSuccess(true);

      if (onReviewAdded) onReviewAdded();

      // Hide success message after 3 seconds
      setTimeout(() => setSuccess(false), 3000);

    } catch (err) {
      if (err.response?.status === 401) {
        setError("Please log in to submit a review.");
      } else {
        setError("Failed to submit review. Please try again.");
      }
      console.error("Error submitting review:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleRatingClick = (value) => {
    setRating(value);
  };

  const handleRatingHover = (value) => {
    setHoveredRating(value);
  };

  const handleRatingLeave = () => {
    setHoveredRating(0);
  };

  const renderStars = () => {
    const currentRating = hoveredRating || rating;
    return (
      <div className="stars-container">
        {[1, 2, 3, 4, 5].map((star) => (
          <FaStar
            key={star}
            className={`star-rating ${star <= currentRating ? 'active' : 'inactive'}`}
            onClick={() => handleRatingClick(star)}
            onMouseEnter={() => handleRatingHover(star)}
            onMouseLeave={handleRatingLeave}
          />
        ))}
        <span className="rating-text">
          {currentRating} star{currentRating !== 1 ? 's' : ''}
        </span>
      </div>
    );
  };

  return (
    <div className="review-form-container">
      {loading && (
        <div className="loading-overlay">
          <div className="loading-spinner"></div>
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <div className="form-group">
          <label htmlFor="user" className="form-label">
            <FaUser className="form-label-icon" />
            Your Name
          </label>
          <input
            id="user"
            type="text"
            className="form-control"
            value={user}
            onChange={(e) => setUser(e.target.value)}
            placeholder="Enter your name"
            required
          />
        </div>

        <div className="rating-section">
          <label className="rating-label">
            <FaStar className="form-label-icon" />
            Your Rating
          </label>
          {renderStars()}
        </div>

        <div className="form-group">
          <label htmlFor="comment" className="form-label">
            <FaComment className="form-label-icon" />
            Your Review
          </label>
          <textarea
            id="comment"
            className="form-control"
            value={comment}
            onChange={(e) => setComment(e.target.value)}
            placeholder="Share your experience and thoughts about this destination..."
            rows={4}
            required
          />
        </div>

        <div className="form-group">
          <label htmlFor="activities" className="form-label">
            <FaMapMarkerAlt className="form-label-icon" />
            Activities (comma separated)
          </label>
          <input
            id="activities"
            type="text"
            className="form-control"
            value={activities}
            onChange={(e) => setActivities(e.target.value)}
            placeholder="e.g., Surfing, Hiking, Photography"
            required
          />
        </div>

        {error && (
          <div className="alert alert-danger">
            <FaExclamationTriangle className="alert-icon" />
            {error}
          </div>
        )}

        {success && (
          <div className="alert alert-success">
            <FaCheckCircle className="alert-icon" />
            Review submitted successfully! Thank you for your feedback.
          </div>
        )}

        <button
          type="submit"
          className="submit-btn"
          disabled={loading}
        >
          <FaPaperPlane style={{ marginRight: '0.5rem' }} />
          {loading ? "Submitting Review..." : "Submit Review"}
        </button>
      </form>
    </div>
  );
}
