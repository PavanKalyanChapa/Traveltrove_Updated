// import { useState, useEffect } from "react";
 
// import { FaStar, FaRegStar } from "react-icons/fa";
 
// import axios from "axios";
 
// const avatarColors = [
 
//   "#FF6B6B",
 
//   "#6BCB77",
 
//   "#4D96FF",
 
//   "#FFD93D",
 
//   "#FF6F91",
 
//   "#845EC2",
 
//   "#00C9A7",
 
//   "#FF9671",
 
// ];
 
// function getAvatarColor(name) {
 
//   if (!name) return "#ccc";
 
//   let hash = 0;
 
//   for (let i = 0; i < name.length; i++) {
 
//     hash = name.charCodeAt(i) + ((hash << 5) - hash);
 
//   }
 
//   const index = Math.abs(hash) % avatarColors.length;
 
//   return avatarColors[index];
 
// }
 
// function Avatar({ name }) {
 
//   const initials = name
 
//     ? name
 
//       .split(" ")
 
//       .map((n) => n[0])
 
//       .join("")
 
//       .toUpperCase()
 
//     : "A";
 
//   const bgColor = getAvatarColor(name);
 
//   return (
 
//     <div
 
//       style={{
 
//         backgroundColor: bgColor,
 
//         width: 50,
 
//         height: 50,
 
//         borderRadius: "50%",
 
//         color: "white",
 
//         display: "flex",
 
//         justifyContent: "center",
 
//         alignItems: "center",
 
//         fontWeight: "bold",
 
//         fontSize: 20,
 
//         userSelect: "none",
 
//         flexShrink: 0,
 
//       }}
 
//       aria-label={`Avatar for ${name}`}
 
//     >
 
//       {initials}
 
//     </div>
 
//   );
 
// }
 
// function StarRating({ rating }) {
 
//   const stars = [];
 
//   for (let i = 1; i <= 5; i++) {
 
//     if (i <= rating) {
 
//       stars.push(<span key={i} className="text-warning" style={{ fontSize: "1.3rem" }}></span>);
 
//     } else {
 
//       stars.push(<span key={i} className="text-muted" style={{ fontSize: "1.3rem" }}></span>);
 
//     }
 
//   }
 
//   return <div aria-label={`Rating: ${rating} out of 5 stars`}>{stars}</div>;
 
// }
 
// const renderStars = (rating) => {
 
//   const fullStars = Math.floor(rating);
 
//   const emptyStars = 5 - fullStars;
 
//   return (
 
//     <>
 
//       {Array(fullStars).fill().map((_, i) => (
 
//         <FaStar key={`full-${i}`} className="text-warning" />
 
//       ))}
 
//       {Array(emptyStars).fill().map((_, i) => (
 
//         <FaRegStar key={`empty-${i}`} className="text-warning" />
 
//       ))}
 
//     </>
 
//   );
 
// };
 
// export default function ReviewList({ location, activity }) {
 
//   const [reviews, setReviews] = useState([]);
 
//   const [loading, setLoading] = useState(true);
 
//   const [error, setError] = useState(null);
 
//   useEffect(() => {
 
//     console.log("Activity filter in ReviewList:", activity); // Debug log
 
//     const fetchReviews = async () => {
 
//       setLoading(true);
 
//       setError(null);
 
//       try {
 
//         const params = {};
 
//         if (location) params.location = location;
 
//         if (activity) params.activity = activity;
 
//         const response = await axios.get("http://localhost:5000/reviews", { params });
 
//         setReviews(response.data.reviews || []);
 
//       } catch (err) {
 
//         setError("Failed to load reviews");
 
//         console.error("Error fetching reviews:", err);
 
//       } finally {
 
//         setLoading(false);
 
//       }
 
//     };
 
//     fetchReviews();
 
//   }, [location, activity]);
 
//   if (loading) {
 
//     return <p>Loading reviews...</p>;
 
//   }
 
//   if (error) {
 
//     return <p className="text-danger">{error}</p>;
 
//   }
 
//   if (reviews.length === 0) {
 
//     return <p>No reviews found.</p>;
 
//   }
 
//   return (
 
//     <div className="row g-4" >
 
//       {reviews.map((review, index) => (
 
//         <div key={index} className="col-md-6 col-lg-4">
 
//           <div className="card shadow-lg h-100 border-0 rounded-4" style={{ background: "rgba(255,255,255,0.2)" }}>
 
//             <div className="card-body d-flex flex-column">
 
//               <div className="d-flex align-items-center mb-3">
 
//                 <Avatar name={review.user} />
 
//                 <div className="ms-3 flex-grow-1">
 
//                   <h5 className="card-title mb-0">{review.user || "Anonymous"}</h5>
            
//                   <small className="text-muted">{review.type === "destination-guide" ? review.location : "Itinerary"}</small>
 
//                 </div>
 
//                 {renderStars(review.rating)}
 
//               </div>
 
//               <p className="card-text flex-grow-1 mt-3" style={{ fontSize: "1rem", color: "#004d40" }}>{review.comment}</p>
 
//               {review.activities && review.activities.length > 0 && (
 
//                 <div className="mt-auto">
 
//                   <strong>Activities:</strong>{" "}
 
//                   {Array.isArray(review.activities) ? (
 
//                     review.activities.map((act, i) => (
 
//                       <span
 
//                         key={i}
 
//                         className="badge  me-1"
 
//                         style={{ backgroundColor: "#135677", color: "white", fontSize: "0.85rem", padding: "0.4em 0.6em" }}
 
//                       >
 
//                         {act}
 
//                       </span>
 
//                     ))
 
//                   ) : (
 
//                     review.activities
 
//                   )}
 
//                 </div>
 
//               )}
 
//             </div>
 
//           </div>
 
//         </div>
 
//       ))}
 
//     </div>
 
//   );
 
// }

import { useState, useEffect } from "react";
import { FaStar, FaRegStar } from "react-icons/fa";
import axios from "axios";

const avatarColors = [
  "#FF6B6B", "#6BCB77", "#4D96FF", "#FFD93D",
  "#FF6F91", "#845EC2", "#00C9A7", "#FF9671",
];

function getAvatarColor(name) {
  if (!name) return "#ccc";
  let hash = 0;
  for (let i = 0; i < name.length; i++) {
    hash = name.charCodeAt(i) + ((hash << 5) - hash);
  }
  const index = Math.abs(hash) % avatarColors.length;
  return avatarColors[index];
}

function Avatar({ name }) {
  const initials = name
    ? name.split(" ").map((n) => n[0]).join("").toUpperCase()
    : "A";
  const bgColor = getAvatarColor(name);

  return (
    <div
      style={{
        backgroundColor: bgColor,
        width: 50,
        height: 50,
        borderRadius: "50%",
        color: "white",
        display: "flex",
        justifyContent: "center",
        alignItems: "center",
        fontWeight: "bold",
        fontSize: 20,
        userSelect: "none",
        flexShrink: 0,
      }}
      aria-label={`Avatar for ${name}`}
    >
      {initials}
    </div>
  );
}

const renderStars = (rating) => {
  const fullStars = Math.floor(rating);
  const emptyStars = 5 - fullStars;
  return (
    <>
      {Array(fullStars).fill().map((_, i) => (
        <FaStar key={`full-${i}`} className="text-warning" />
      ))}
      {Array(emptyStars).fill().map((_, i) => (
        <FaRegStar key={`empty-${i}`} className="text-warning" />
      ))}
    </>
  );
};

export default function ReviewList({ location, activity, onReviewsFetched }) {
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchReviews = async () => {
      setLoading(true);
      setError(null);
      try {
        const params = {};
        if (location) params.location = location;
        if (activity) params.activity = activity;

        const response = await axios.get("http://localhost:5000/reviews", { params });
        const fetchedReviews = response.data.reviews || [];
        setReviews(fetchedReviews);

        // ✅ Pass fetched reviews back to parent
        if (onReviewsFetched) {
          onReviewsFetched(fetchedReviews);
        }
      } catch (err) {
        setError("Failed to load reviews");
        console.error("Error fetching reviews:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchReviews();
  }, [location, activity, onReviewsFetched]);

  if (loading) return <p>Loading reviews...</p>;
  if (error) return <p className="text-danger">{error}</p>;
  if (reviews.length === 0) return <p>No reviews found.</p>;

  return (
    <div className="row g-4">
      {reviews.map((review, index) => (
        <div key={index} className="col-md-6 col-lg-4">
          <div
            className="card shadow-lg h-100 border-0 rounded-4"
            style={{ background: "rgba(255,255,255,0.2)" }}
          >
            <div className="card-body d-flex flex-column">
              <div className="d-flex align-items-center mb-3">
                <Avatar name={review.user} />
                <div className="ms-3 flex-grow-1">
                  <h5 className="card-title mb-0">
                    {review.user || "Anonymous"}
                  </h5>
                  <small className="text-muted">
                    {review.type === "destination-guide"
                      ? review.location
                      : "Itinerary"}
                  </small>
                </div>
                {renderStars(review.rating)}
              </div>

              <p
                className="card-text flex-grow-1 mt-3"
                style={{ fontSize: "1rem", color: "#004d40" }}
              >
                {review.comment}
              </p>

              {review.activities && review.activities.length > 0 && (
                <div className="mt-auto">
                  <strong>Activities:</strong>{" "}
                  {Array.isArray(review.activities) ? (
                    review.activities.map((act, i) => (
                      <span
                        key={i}
                        className="badge me-1"
                        style={{
                          backgroundColor: "#135677",
                          color: "white",
                          fontSize: "0.85rem",
                          padding: "0.4em 0.6em",
                        }}
                      >
                        {act}
                      </span>
                    ))
                  ) : (
                    review.activities
                  )}
                </div>
              )}
            </div>
          </div>
        </div>
      ))}
    </div>
  );
}
