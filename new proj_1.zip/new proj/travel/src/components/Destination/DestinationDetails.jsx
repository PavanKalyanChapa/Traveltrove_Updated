import { useParams, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";
import axios from "axios";
import { FaArrowLeft, FaStar, FaHeart, FaPlus } from "react-icons/fa";
import ItineraryList from "../itinerary/ItineraryList";
import ReviewForm from "./ReviewForm";
import { useAuth } from '../../contexts/AuthContext';
export default function DestinationDetails() {
    const { id } = useParams();
    const navigate = useNavigate();
    const { isAuthenticated, token , userObj } = useAuth();
    const [destination, setDestination] = useState(null);
    const [activeTab, setActiveTab] = useState("overview");
    const [itineraries, setItineraries] = useState([]);
    const [loadingItinerary, setLoadingItinerary] = useState(true);
    const [isFavorite, setIsFavorite] = useState(false);
    const [loadingFavorite, setLoadingFavorite] = useState(false);
    const [reviews, setReviews] = useState([]);
    const [loadingReviews, setLoadingReviews] = useState(true);
    const [reviewsError, setReviewsError] = useState(null);
    const [showReviewModal, setShowReviewModal] = useState(false);
    const fetchReviews = async () => {
        setLoadingReviews(true);
        setReviewsError(null);
        try {
            const response = await axios.get("http://localhost:5000/reviews", {
                params: { type: "destination-guide", id }
            });
            setReviews(response.data.reviews || []);
        } catch (err) {
            setReviewsError("Failed to load reviews");
            console.error("Error fetching reviews:", err);
        } finally {
            setLoadingReviews(false);
        }
    };
    useEffect(() => {
        axios
            .get("http://localhost:5000/destinations")
            .then((res) => {
                const match = res.data.find((d) => d.destinationId === Number(id));
                if (match) {
                    setDestination(match);
                } else {
                    setDestination("not-found");
                }
            })
            .catch(() => setDestination("not-found"));
    }, [id]);
    useEffect(() => {
        const fetchItineraries = async () => {
            try {
                const response = await fetch(`http://localhost:5000/trip-itineraries/${id}/${userObj.userId}`,
                   { headers: { Authorization: `Bearer ${token}` } }
                );
                const data = await response.json();
                setItineraries(data.itineraries || []);
                setLoadingItinerary(false);
            } catch (error) {
                console.error("Error in fetching itineraries", error);
                setLoadingItinerary(false);
            }
        };
       if(userObj.userId) fetchItineraries();
        fetchReviews();
    }, [userObj]);
    useEffect(() => {
        const checkFavoriteStatus = async () => {
            if (!isAuthenticated || !token) return;
            try {
                const response = await axios.get("http://localhost:5000/favorites", {
                    headers: { Authorization: `Bearer ${token}` }
                });
                const favorites = response.data.favorites || [];
                const isFav = favorites.some(fav => fav.type === "destination-guide" && fav.id === Number(id));
                setIsFavorite(isFav);
            } catch (error) {
                console.error("Error checking favorite status:", error);
            }
        };
        if (destination && isAuthenticated) {
            checkFavoriteStatus();
        }
    }, [id, destination, isAuthenticated, token]);
    const toggleFavorite = async () => {
        if (loadingFavorite) return;
        if (!isAuthenticated) {
            alert("Please log in to save favorites.");
            setTimeout(() => navigate("/login"), 100);
            return;
        }
        setLoadingFavorite(true);
        try {
            if (isFavorite) {
                await axios.delete(`http://localhost:5000/favorites/${id}`, {
                    headers: { Authorization: `Bearer ${token}` }
                });
                setIsFavorite(false);
            } else {
                await axios.post("http://localhost:5000/favorites", {
                    type: "destination-guide",
                    id: Number(id)
                }, {
                    headers: { Authorization: `Bearer ${token}` }
                });
                setIsFavorite(true);
            }
        } catch (error) {
            console.error("Error toggling favorite:", error);
            if (error.response?.status === 401) {
                alert("Please log in to save favorites.");
                setTimeout(() => navigate("/login"), 100);
            } else {
                alert("Error saving favorite. Please try again.");
            }
        } finally {
            setLoadingFavorite(false);
        }
    };
    if (destination === "not-found") {
        return (
            <div className="container my-5 text-center">
                <h3>Destination guide not found</h3>
                <button className="btn btn-primary mt-3" onClick={() => navigate(-1)}>
                    Go Back
                </button>
            </div>
        );
    }
    if (!destination) {
        return (
            <div className="container text-center my-5">
                <div className="spinner-border text-primary" />
                <p>Loading...</p>
            </div>
        );
    }
    const averageRating = reviews.length > 0 ? (reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length).toFixed(1) : "N/A";
    return (
        <div className="container my-4" style={{ width: "100vw", maxWidth: "100vw", padding: "0 15px" }}>
            {/* Back button */}
            <button className="booking-btn mb-3" onClick={() => navigate("/")}>
                <FaArrowLeft /> Back
            </button>
            {/* Image */}
            <div style={{ marginBottom: "20px" }}>
                <img
                    src={`/${destination.photo}`}
                    alt={destination.destinationName}
                    style={{ width: "100%", borderRadius: "10px", objectFit: "cover", maxHeight: "300px" }}
                />
            </div>
            {/* Title and location */}
            <h2 className="destination-title" style={{ fontWeight: "bold", marginBottom: "15px", fontSize: "2.5rem", color: "#F1A501" }}>
                {destination.destinationName}
            </h2>
            {/* Rating and reviews */}
            <div className="rating-section" style={{ display: "flex", marginBottom: "20px", marginLeft:"-0.8rem"}}>
                <div
                    style={{
                        backgroundColor: "#F1A501",
                        color: "white",
                        padding: "5px 12px",
                        borderRadius: "8px",
                        marginRight: "10px",
                        fontWeight: "600",
                        fontSize: "1rem",
                        minWidth: "60px",
                        textAlign: "center",
                    }}
                >
                    {averageRating} <FaStar />
                </div>
                <div style={{ color: "#555", fontSize: "1rem" }}>
                    Based on {reviews.length} review{reviews.length !== 1 ? "s" : ""}
                </div>
            </div>
            {/* Description */}
            <p style={{ marginBottom: "20px", color: "#333", fontSize: "1.1rem", lineHeight: "1.6" }}>
                {destination.destinationSummary}
            </p>
            {/* Save and Share buttons */}
            <div className="save-buttons" style={{ display: "flex", gap: "10px", marginBottom: "30px" }}>
                <button
                    className={isFavorite ? "booking-btn" : "contact-btn"}
                    onClick={toggleFavorite}
                    disabled={loadingFavorite}
                >
                    <FaHeart className="me-1" />
                    {isFavorite ? "Remove from Favorites" : "Add to Favorites"}
                </button>
            </div>
            {/* Nav Tabs */}
            <ul className="nav nav-tabs modern-tabs" style={{ marginBottom: "20px" }}>
                <li className="nav-item">
                    <button
                        className={`nav-link ${activeTab === "overview" ? "active" : ""}`}
                        onClick={() => setActiveTab("overview")}
                    >
                        Overview
                    </button>
                </li>
                <li className="nav-item">
                    <button
                        className={`nav-link ${activeTab === "itinerary" ? "active" : ""}`}
                        onClick={() => setActiveTab("itinerary")}
                    >
                        Itinerary Planner
                    </button>
                </li>
                <li className="nav-item">
                    <button
                        className={`nav-link ${activeTab === "reviews" ? "active" : ""}`}
                        onClick={() => setActiveTab("reviews")}
                    >
                        Reviews ({reviews.length})
                    </button>
                </li>
            </ul>
            {/* Tab Content */}
            <div className="tab-content">
                {activeTab === "overview" && (
                    <div className="tab-pane active" style={{ fontSize: "1rem", color: "#444", lineHeight: "1.6" }}>
                        <h4 style={{ color: "#F1A501", fontWeight: "700", marginBottom: "10px" }}>
                            About {destination.destinationName}
                        </h4>
                        <p>{destination.description || destination.destinationSummary}</p>
                        <h4 style={{ color: "#F1A501", fontWeight: "700", marginTop: "20px", marginBottom: "10px" }}>
                            History
                        </h4>
                        <p>{destination.history}</p>
                        <h4 style={{ color: "#F1A501", fontWeight: "700", marginTop: "20px", marginBottom: "10px" }}>
                            Culture
                        </h4>
                        <p>{destination.culture}</p>
                        <h4 style={{ color: "#F1A501", fontWeight: "700", marginTop: "20px", marginBottom: "10px" }}>
                            Top Attractions
                        </h4>
                        <ul>
                            {destination.touristAttractions.map((place, i) => (
                                <li key={i}>{place}</li>
                            ))}
                        </ul>
                        <h4
                            style={{
                                marginTop: "30px",
                                backgroundColor: "#F1A501",
                                color: "white",
                                padding: "8px 12px",
                                borderRadius: "8px",
                            }}
                        >
                            Recommended Stays
                        </h4>
                        {destination.recommendedHotels.map((hotel, i) => (
                            <div
                                key={i}
                                style={{
                                    borderBottom: "1px solid #ddd",
                                    paddingBottom: "12px",
                                    marginBottom: "12px",
                                }}
                            >
                                <strong>{hotel.hotelName}</strong> <br />
                                <span style={{ color: "#555" }}>{hotel.type || "Luxury"}</span>
                                <span
                                    style={{
                                        float: "right",
                                        color: "#F1A501",
                                        fontWeight: "700",
                                    }}
                                >
                                    ${hotel.price}+
                                </span>
                                <div style={{ color: "#f39c12" }}>
                                    {Array(Math.round(hotel.rating))
                                        .fill()
                                        .map((_, i) => (
                                            <FaStar key={i} />
                                        ))}
                                </div>
                            </div>
                        ))}
                        <h4
                            style={{
                                marginTop: "30px",
                                backgroundColor: "#F1A501",
                                color: "white",
                                padding: "8px 12px",
                                borderRadius: "8px",
                            }}
                        >
                            Dining Options
                        </h4>
                        {destination.recommendedRestaurants.map((res, i) => (
                            <div
                                key={i}
                                style={{
                                    borderBottom: "1px solid #ddd",
                                    paddingBottom: "12px",
                                    marginBottom: "12px",
                                }}
                            >
                                <strong>{res.restaurantName}</strong> <br />
                                <span style={{ color: "#555" }}>{res.cuisine}</span>
                                {/* <span
                                    style={{
                                        float: "right",
                                        color: "#F1A501",
                                        fontWeight: "700",
                                    }}
                                >
                                    {res.priceRange || "$$$"}
                                </span> */}
                                <div style={{ color: "#f39c12" }}>
                                    {Array(Math.round(res.rating))
                                        .fill()
                                        .map((_, i) => (
                                            <FaStar key={i} />
                                        ))}
                                </div>
                            </div>
                        ))}
                    </div>
                )}
                {activeTab === "itinerary" && (
                    <div className="tab-pane active" style={{ fontSize: "1rem", color: "#444" }}>
                        <h4 style={{ color: "#F1A501", fontWeight: "700", marginBottom: "10px" }}>Itinerary Planner</h4>
                        {loadingItinerary ? (
                            <p>Loading itineraries...</p>
                        ) : itineraries.length === 0 ? (
                            <div className="text-center">
                                <p>No itineraries found for this destination.</p>
                            </div>
                        ) : (
                            <ItineraryList itineraries={itineraries} />
                        )}
                        <div className="text-center mt-3">
                            <button
                                className="contact-btn"
                                onClick={() => {
                                    if (!isAuthenticated) {
                                        alert("Please log in to create an itinerary.");
                                        setTimeout(() => navigate("/login"), 100);
                                    } else {
                                        navigate(`/create-itinerary/${destination.destinationId}`);
                                    }
                                }}
                            >
                                Create Itinerary
                            </button>
                        </div>
                    </div>
                )}
                {activeTab === "reviews" && (
                    <div className="tab-pane active" style={{ fontSize: "1rem", color: "#444" }}>
                        <h4 style={{ color: "#e09401", fontWeight: "700", marginBottom: "10px" }}>User Reviews</h4>
                        {loadingReviews ? (
                            <p>Loading reviews...</p>
                        ) : reviewsError ? (
                            <p style={{ color: "red" }}>{reviewsError}</p>
                        ) : reviews.length === 0 ? (
                            <p>No reviews yet.</p>
                        ) : (
                            reviews.map((rev, i) => (
                                <div key={i} className="border rounded p-3 mb-3" style={{ backgroundColor: "#f9f9f9" }}>
                                    <strong>{rev.user || "Anonymous"}</strong> - <FaStar style={{ color: "#f39c12" }} /> {rev.rating}
                                    <p style={{ marginTop: "5px", whiteSpace: "pre-wrap" }}>{rev.comment}</p>
                                </div>
                            ))
                        )}
                        <button
                            className="contact-btn mt-3"
                            onClick={() => setShowReviewModal(true)}
                        >
                            <FaPlus /> Add Review
                        </button>
                        {showReviewModal && (
                            <div
                                className="modal-overlay"
                                onClick={() => setShowReviewModal(false)}
                                style={{
                                    position: "fixed",
                                    top: 0,
                                    left: 0,
                                    right: 0,
                                    bottom: 0,
                                    backgroundColor: "rgba(0,0,0,0.5)",
                                    display: "flex",
                                    justifyContent: "center",
                                    alignItems: "center",
                                    zIndex: 1050,
                                }}
                            >
                                <div
                                    className="modal-content"
                                    onClick={(e) => e.stopPropagation()}
                                    style={{
                                        backgroundColor: "white",
                                        borderRadius: "20px",
                                        padding: "20px",
                                        maxWidth: "900px",
                                        width: "90%",
                                        maxHeight: "90vh",
                                        overflowY: "auto",
                                        boxShadow: "0 10px 40px rgba(0,0,0,0.3)",
                                        position: "relative",
                                    }}
                                >
                                    <button
                                        className="modal-close"
                                        onClick={() => setShowReviewModal(false)}
                                        style={{
                                            position: "absolute",
                                            top: "15px",
                                            right: "20px",
                                            background: "rgba(255,255,255,0.9)",
                                            border: "none",
                                            borderRadius: "50%",
                                            width: "35px",
                                            height: "35px",
                                            fontSize: "20px",
                                            cursor: "pointer",
                                            boxShadow: "0 2px 10px rgba(0,0,0,0.1)",
                                        }}
                                    >
                                        ×
                                    </button>
                                    <ReviewForm
                                        type="destination-guide"
                                        id={destination.destinationId}
                                        location={destination.destinationName}
                                        token={token}
                                        onReviewAdded={() => {
                                            fetchReviews();
                                            setShowReviewModal(false);
                                        }}
                                    />
                                </div>
                            </div>
                        )}
                    </div>
                )}
            </div>
        </div>
    );
}
