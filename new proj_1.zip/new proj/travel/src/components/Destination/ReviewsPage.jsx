import { useState } from "react";
import { FaSearch, FaFilter, FaStar, FaMapMarkerAlt } from "react-icons/fa";
import ReviewList from "./ReviewList";
import "./ReviewsPage.css";

export default function ReviewsPage() {
  const [locationFilter, setLocationFilter] = useState("");
  const [activityFilter, setActivityFilter] = useState("");
  const [showFilters, setShowFilters] = useState(false);

  // 🔑 New state for reviews + average rating
  const [avgRating, setAvgRating] = useState(0);
  const [reviewCount, setReviewCount] = useState(0);
  const [hasValidResults, setHasValidResults] = useState(true); // 👈 new

  return (
    <div className="reviews-page">
      <div className="reviews-hero">
        <div className="hero-overlay"></div>
        <div className="hero-content">
          <div className="category-title">
            <h3>Traveler Reviews</h3>
            <h5>Discover authentic experiences from our global community of explorers</h5>


            {/* 🔥 Dynamic stats */}
            <div className="hero-stats">
              <div className="stat-item">
                <FaStar className="stat-icon" />
                <span className="stat-number">{avgRating}</span>
                <span className="stat-label">
                  {reviewCount > 0
                    ? "Average Rating"
                    : hasValidResults
                      ? "No Reviews Yet"
                      : "No Reviews Found"}
                </span>
              </div>
              <div className="stat-item">
                <FaMapMarkerAlt className="stat-icon" />
                <span className="stat-number">{reviewCount}</span>
                <span className="stat-label">Reviews Found</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Filters */}
      <div className="reviews-container">
        <div className="reviews-header">
          <div className="header-content">
            <h2 className="section-title">What Travelers Say</h2>
            <p className="section-subtitle">
              Real experiences, honest opinions from fellow adventurers
            </p>
          </div>

          <button
            className="filter-toggle-btn"
            onClick={() => setShowFilters(!showFilters)}
          >
            <FaFilter className="filter-icon" />
            <span>Filters</span>
            <div className={`toggle-arrow ${showFilters ? "active" : ""}`}>
              ▼
            </div>
          </button>
        </div>

        {/* Filters Section */}
        <div className={`filters-section ${showFilters ? "active" : ""}`}>
          <div className="filters-grid">
            <div className="filter-group">
              <label className="filter-label">
                <FaMapMarkerAlt className="label-icon" />
                Destination
              </label>
              <div className="input-wrapper">
                <FaSearch className="input-icon" />
                <input
                  type="text"
                  className="filter-input"
                  value={locationFilter}
                  onChange={(e) => setLocationFilter(e.target.value)}
                  placeholder="Search destinations..."
                />
              </div>
            </div>

            <div className="filter-group">
              <label className="filter-label">
                <FaStar className="label-icon" />
                Activity
              </label>
              <div className="input-wrapper">
                <FaSearch className="input-icon" />
                <input
                  type="text"
                  className="filter-input"
                  value={activityFilter}
                  onChange={(e) => setActivityFilter(e.target.value)}
                  placeholder="Search activities..."
                />
              </div>
            </div>
          </div>

          {(locationFilter || activityFilter) && (
            <div className="active-filters">
              <span className="filters-label">Active filters:</span>
              <div className="filter-tags">
                {locationFilter && (
                  <span className="filter-tag">
                    <FaMapMarkerAlt className="tag-icon" />
                    {locationFilter}
                    <button
                      className="tag-remove"
                      onClick={() => setLocationFilter("")}
                    >
                      ×
                    </button>
                  </span>
                )}
                {activityFilter && (
                  <span className="filter-tag">
                    <FaStar className="tag-icon" />
                    {activityFilter}
                    <button
                      className="tag-remove"
                      onClick={() => setActivityFilter("")}
                    >
                      ×
                    </button>
                  </span>
                )}
              </div>
              <button
                className="clear-filters-btn"
                onClick={() => {
                  setLocationFilter("");
                  setActivityFilter("");
                }}
              >
                Clear All
              </button>
            </div>
          )}
        </div>

        {/* Reviews List */}
        {/* Reviews List */}
        <div className="reviews-content">
          <ReviewList
            location={locationFilter}
            activity={activityFilter}
            onReviewsFetched={(reviews) => {
              if (reviews.length > 0) {
                setHasValidResults(true);
                setReviewCount(reviews.length);
                const avg =
                  reviews.reduce((sum, r) => sum + r.rating, 0) / reviews.length;
                setAvgRating(avg.toFixed(1));
              } else {
                setHasValidResults(false);
                setReviewCount(0);
                setAvgRating(0);
              }
            }}
          />

          {!hasValidResults && (
            <p style={{ textAlign: "center", marginTop: "2rem", color: "#888" }}>
              No reviews found for your search.
            </p>
          )}
        </div>

      </div>
    </div>
  );
}
