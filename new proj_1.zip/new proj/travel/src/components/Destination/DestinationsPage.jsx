import React, { useEffect, useState } from 'react';
import axios from 'axios';
import DestinationCard from './DestinationCard';

export default function DestinationsPage() {
  const [destinations, setDestinations] = useState([]);

  useEffect(() => {
    const fetchDestinations = async () => {
      try {
        const res = await axios.get('http://localhost:5000/destinations');
        setDestinations(Array.isArray(res.data) ? res.data : []);
      } catch (error) {
        console.error(error);
      }
    };
    fetchDestinations();
  }, []);

  return (
    <div className="container my-5">
      <div class="category-title ">
        <h3>All Destinations</h3>
        <h5>Discover our most popular destination guides</h5>
      </div>
      <div className="card-grid">
        {destinations.map(dest => (
          <DestinationCard
            key={dest.destinationId}
            guide={dest}
          />
        ))}
      </div>
    </div>
  );
}
