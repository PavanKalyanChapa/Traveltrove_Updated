import { useState, useEffect } from "react";
import { FaStar, FaRegStar, FaHeart } from "react-icons/fa";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { useAuth } from '../../contexts/AuthContext';
import './DestinationCard.css';

const DestinationCard = ({ guide }) => {
  const { isAuthenticated, token } = useAuth();
  const [isFavorite, setIsFavorite] = useState(false);
  const [loading, setLoading] = useState(false);
  const [averageRating, setAverageRating] = useState(0);
  const [totalReviews, setTotalReviews] = useState(0);
  const navigate = useNavigate();

  useEffect(() => {
    const checkFavoriteStatus = async () => {
      if (!isAuthenticated || !token) {
        setIsFavorite(false);
        return;
      }
      try {
        const response = await axios.get("http://localhost:5000/favorites", {
          headers: { Authorization: `Bearer ${token}` }
        });
        const favorites = response.data.favorites || [];
        const isFav = favorites.some(fav => fav.type === "destination-guide" && fav.id === guide.destinationId);
        setIsFavorite(isFav);
      } catch (error) {
        console.error("Error checking favorite status:", error);
        setIsFavorite(false);
      }
    };
    checkFavoriteStatus();
  }, [guide.destinationId, isAuthenticated, token]);

  useEffect(() => {
    const fetchReviews = async () => {
      try {
        const response = await axios.get("http://localhost:5000/reviews", {
          params: { type: "destination-guide", id: guide.destinationId }
        });
        const Reviews = response.data.reviews || [];
        if (Reviews.length > 0) {
          const avg = (Reviews.reduce((sum, r) => sum + r.rating, 0) / Reviews.length).toFixed(1);
          setAverageRating(avg);
          setTotalReviews(Reviews.length);
        }
      } catch (err) {
        console.error("Error fetching reviews:", err);
      }
    };
    fetchReviews();
  }, [guide.destinationId]);

  const toggleFavorite = async () => {
    if (loading) return;
    if (!isAuthenticated) {
      alert("Please log in to save favorites");
      return;
    }
    setLoading(true);
    try {
      if (isFavorite) {
        await axios.delete(`http://localhost:5000/favorites/${guide.destinationId}`, {
          headers: { Authorization: `Bearer ${token}` }
        });
        setIsFavorite(false);
      } else {
        await axios.post("http://localhost:5000/favorites", {
          type: "destination-guide",
          id: guide.destinationId
        }, {
          headers: { Authorization: `Bearer ${token}` }
        });
        setIsFavorite(true);
      }
    } catch (error) {
      console.error("Error toggling favorite:", error);
      if (error.response?.status === 401) {
        alert("Please log in to save favorites");
      } else {
        alert("Error saving favorite. Please try again.");
      }
    } finally {
      setLoading(false);
    }
  };

  const renderStars = (rating) => {
    const fullStars = Math.floor(rating);
    const emptyStars = 5 - fullStars;
    return (
      <>
        {Array(fullStars).fill().map((_, i) => (
          <FaStar key={`full-${i}`} className="text-warning" />
        ))}
        {Array(emptyStars).fill().map((_, i) => (
          <FaRegStar key={`empty-${i}`} className="text-warning" />
        ))}
      </>
    );
  };

return (
  <div className="tcard">
    <img
      src={guide.photo}
      className="imag"
      alt={guide.title}
    />
    <div className="card-body">
      {/* Centered title and description */}
      <h5 className="card-title">{guide.title}</h5>
      <p className="card-text">{guide.destinationSummary}</p>
      
      {/* Reviews left, favorite right */}
      <div className="card-footer">
        <div className="rating-section">
          <div className="stars-container">
            {renderStars(averageRating)}
          </div>
          <span className="review-text">({totalReviews} reviews)</span>
        </div>
        <FaHeart
          className={`favorite-icon ${isFavorite ? "text-danger" : "text-secondary"}`}
          onClick={toggleFavorite}
        />
      </div>

      {/* Centered button with margin */}
      <div className="button-container">
        <button
          className="btt"
          onClick={() => {
            if (!isAuthenticated) {
              navigate('/login');
            } else {
              navigate(`/destinations/${guide.destinationId}`);
            }
          }}
        >
          View More
        </button>
      </div>
    </div>
  </div>
);


};

export default DestinationCard;

