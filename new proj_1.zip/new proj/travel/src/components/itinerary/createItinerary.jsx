import React, { useState, useEffect } from "react";
import { useParams, useNavigate } from "react-router-dom";
import { useAuth } from "../../contexts/AuthContext";
import axios from "axios";

const CreateItinerary = () => {
    const { userObj } = useAuth();
    const { destinationId } = useParams();
    const navigate = useNavigate();
    const [error, setError] = useState(null);

    const [itinerary, setItinerary] = useState({
        id: Date.now() + Math.floor(Math.random() * 1000),
        userId: userObj.userId,
        destinationId: destinationId || "",
        destination: "",
        duration: "",
        activities: [],
        recommendedHotels: [],
        recommendedRestaurants: [],
    });

    useEffect(() => {
        const token = localStorage.getItem("token");
        if (!token) {
            alert("Please log in to create an itinerary.");
            navigate("/login");
            return;
        }
        axios.defaults.headers.common['Authorization'] = `Bearer ${token}`;
    }, [navigate]);
    // State management
    const [activeTab, setActiveTab] = useState('hotels');
    const [selectedItems, setSelectedItems] = useState({
        hotels: [],
        restaurants: [],
        activities: []
    });
    const [filters, setFilters] = useState({
        hotels: { maxPrice: 1000, minRating: 0 },
        restaurants: { cuisine: 'all', minRating: 0 },
        activities: { difficulty: 'all', duration: 'all' }
    });
    const [destination, setDestination] = useState({ destinationName: 'Bali' });
    const [isLoading, setIsLoading] = useState(false);
    const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);
    const [isTablet, setIsTablet] = useState(window.innerWidth <= 1024 && window.innerWidth > 768);
    const [recommendations, setRecommendations] = useState({
        hotels: [],
        restaurants: [],
        activities: []
    });

    // Handle responsive design
    useEffect(() => {
        const handleResize = () => {
            setIsMobile(window.innerWidth <= 768);
            setIsTablet(window.innerWidth <= 1024 && window.innerWidth > 768);
        };
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    const handleSubmit = async () => {
        if (!itinerary.duration) {
            alert("Please enter the duration for your trip.");
            return;
        }

        if (selectedItems.hotels.length === 0 && selectedItems.restaurants.length === 0 && selectedItems.activities.length === 0) {
            alert("Please select at least one item for your itinerary.");
            return;
        }
         
        const newlogging = selectedItems.hotels.map(hotel => hotel.hotelName);
        const newdining = selectedItems.restaurants.map(restaurants => restaurants.restaurantName);
        const newactivities = selectedItems.activities.map(activity => activity.name);

        const formattedItinerary = {
            id: itinerary.id,
            userId: userObj.userId,
            destinationId: Number(destinationId),
            destination: destination.destinationName,
            duration: itinerary.duration,
            lodging: newlogging,
            dining: newdining,
            activities: newactivities
        };
         
        console.log(formattedItinerary);
        setIsLoading(true);
        try {
            const response = await axios.post("http://localhost:5000/trip-itineraries", formattedItinerary);
            alert("Itinerary created successfully!");
            
            setSelectedItems({
                hotels: [],
                restaurants: [],
                activities: []
            });
            
            navigate("/itineraries");
            
        } catch (error) {
            console.error("Error creating itinerary:", error);
            if (error.response?.status === 401) {
                alert("Please log in to create an itinerary.");
                navigate("/login");
            } else {
                alert("Failed to create itinerary. Please try again.");
            }
        } finally {
            setIsLoading(false);
        }
    };

    useEffect(() => {
        const fetchDestination = async () => {
            try {
                const response = await axios.get("http://localhost:5000/destinations");
                const dest = response.data.find(d => d.destinationId === Number(destinationId));
                if (dest) {
                    setDestination(dest);
                    setItinerary(prev => ({
                        ...prev,
                        destination: dest.destinationName,
                        destinationId: dest.destinationId
                    }));
                    
                    if (dest.recommendedHotels) {
                        setRecommendations(prev => ({
                            ...prev,
                            hotels: dest.recommendedHotels
                        }));
                    }
                    if (dest.recommendedRestaurants) {
                        setRecommendations(prev => ({
                            ...prev,
                            restaurants: dest.recommendedRestaurants
                        }));
                    }
                    if (dest.touristAttractions) {
                        const convertedActivities = dest.touristAttractions.map((attraction, index) => ({
                            id: `activity-${dest.destinationId}-${index}`,
                            name: attraction,
                            type: "Tourist Attraction",
                            difficulty: "Easy",
                            duration: "2-4 hours"
                        }));
                        setRecommendations(prev => ({
                            ...prev,
                            activities: convertedActivities
                        }));
                    }
                } else {
                    setError("Destination not found. The location may not be available.");
                }
            } catch (error) {
                console.error("Error fetching destination:", error);
            }
        };
        if (destinationId) {
            fetchDestination();
        }
    }, [destinationId]);
    // Filter functions
    const getFilteredRecommendations = (type) => {
        const items = recommendations[type] || [];
        switch (type) {
            case 'hotels':
                return items.filter(hotel => 
                    hotel.price <= filters.hotels.maxPrice && 
                    hotel.rating >= filters.hotels.minRating
                );
            case 'restaurants':
                return items.filter(restaurant => 
                    (filters.restaurants.cuisine === 'all' || restaurant.cuisine === filters.restaurants.cuisine) &&
                    restaurant.rating >= filters.restaurants.minRating
                );
            case 'activities':
                return items.filter(activity => 
                    (filters.activities.difficulty === 'all' || activity.difficulty === filters.activities.difficulty) &&
                    (filters.activities.duration === 'all' || activity.duration.includes(filters.activities.duration))
                );
            default:
                return items;
        }
    };

    const addToItinerary = (type, item) => {
        const itemWithId = {
            ...item,
            id: item.id || `${type}-${Date.now()}-${Math.random()}`
        };
        setSelectedItems(prev => ({
            ...prev,
            [type]: [...prev[type], itemWithId]
        }));
    };

    const removeFromItinerary = (type, itemId) => {
        setSelectedItems(prev => ({
            ...prev,
            [type]: prev[type].filter(item => item.id !== itemId)
        }));
    };

    return (
        <div style={{
            minHeight: '100vh',
            fontFamily: "'Inter', -apple-system, BlinkMacSystemFont, sans-serif",
            WebkitFontSmoothing: 'antialiased',
            MozOsxFontSmoothing: 'grayscale'
        }}>
            {/* Header Section */}
            <div style={{
                background: 'linear-gradient(135deg, #F1A501 0%, #DF6951 100%)',
                color: 'white',
                padding: isMobile ? '40px 15px' : isTablet ? '50px 20px' : '60px 20px',
                textAlign: 'center'
            }}>
                <div style={{ maxWidth: '1200px', margin: '0 auto' }}>
                    <h1 style={{
                        fontSize: isMobile ? '2rem' : isTablet ? '2.5rem' : '3rem',
                        fontWeight: '700',
                        marginBottom: isMobile ? '12px' : '16px',
                        textShadow: '0 2px 4px rgba(0,0,0,0.1)',
                        lineHeight: isMobile ? '1.2' : '1.1'
                    }}>
                        Create Your Itinerary
                    </h1>
                    <p style={{
                        fontSize: isMobile ? '1rem' : isTablet ? '1.1rem' : '1.25rem',
                        opacity: 0.9,
                        maxWidth: isMobile ? '100%' : '600px',
                        margin: '0 auto',
                        lineHeight: isMobile ? '1.4' : '1.3',
                        padding: isMobile ? '0 10px' : '0'
                    }}>
                        Choose from recommended hotels, restaurants, and activities to build your perfect trip to {destination.destinationName}
                    </p>
                </div>
            </div>

            <div style={{
                maxWidth: '1400px',
                margin: '0 auto',
                padding: isMobile ? '15px 10px' : isTablet ? '25px 15px' : '40px 20px',
                display: isMobile ? 'block' : 'grid',
                gridTemplateColumns: isTablet ? '1fr 350px' : '1fr 400px',
                gap: isMobile ? '0' : isTablet ? '25px' : '40px'
            }}>
                {/* Main Content Area */}
                <div>
                    {/* Tab Navigation */}
                    <div style={{
                        display: 'flex',
                        backgroundColor: 'white',
                        borderRadius: isMobile ? '6px' : '12px',
                        padding: isMobile ? '3px' : '8px',
                        marginBottom: isMobile ? '15px' : '30px',
                        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
                        border: '1px solid #DF6951',
                        overflow: isMobile ? 'auto' : 'visible',
                        WebkitOverflowScrolling: 'touch'
                    }}>
                        {[
                            { key: 'hotels', label: '🏨 Hotels', icon: '🏨' },
                            { key: 'restaurants', label: '🍽️ Restaurants', icon: '🍽️' },
                            { key: 'activities', label: '🎯 Activities', icon: '🎯' }
                        ].map(tab => (
                            <button
                                key={tab.key}
                                onClick={() => setActiveTab(tab.key)}
                                style={{
                                    flex: 1,
                                    minWidth: isMobile ? '100px' : 'auto',
                                    padding: isMobile ? '14px 6px' : '16px 24px',
                                    border: 'none',
                                    borderRadius: isMobile ? '4px' : '8px',
                                    backgroundColor: activeTab === tab.key ? '#F1A501' : 'transparent',
                                    color: activeTab === tab.key ? 'white' : '#DF6951',
                                    fontSize: isMobile ? '13px' : '16px',
                                    fontWeight: '600',
                                    cursor: 'pointer',
                                    transition: 'all 0.2s ease',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    gap: isMobile ? '3px' : '8px',
                                    whiteSpace: 'nowrap',
                                    minHeight: isMobile ? '48px' : 'auto',
                                    WebkitTapHighlightColor: 'transparent'
                                }}
                            >
                                <span style={{ fontSize: isMobile ? '14px' : '20px' }}>{tab.icon}</span>
                                <span style={{ display: isMobile ? 'none' : 'inline' }}>
                                    {tab.label.replace(tab.icon + ' ', '')}
                                </span>
                                <span style={{ display: isMobile ? 'inline' : 'none' }}>
                                    {tab.label.replace(tab.icon + ' ', '').split(' ')[0]}
                                </span>
                            </button>
                        ))}
                    </div>

                    {/* Filters */}
                    <div style={{
                        backgroundColor: 'white',
                        padding: isMobile ? '12px' : '24px',
                        borderRadius: isMobile ? '6px' : '12px',
                        marginBottom: isMobile ? '15px' : '30px',
                        boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
                        border: '1px solid #DF6951'
                    }}>
                        <h3 style={{ 
                            margin: '0 0 12px 0', 
                            color: '#DF6951', 
                            fontSize: isMobile ? '15px' : '18px', 
                            fontWeight: '600' 
                        }}>
                            🔍 Filters
                        </h3>
                        
                        {activeTab === 'hotels' && (
                            <div style={{ 
                                display: 'flex', 
                                gap: isMobile ? '15px' : '20px', 
                                alignItems: isMobile ? 'flex-start' : 'center', 
                                flexWrap: 'wrap',
                                flexDirection: isMobile ? 'column' : 'row'
                            }}>
                                <div style={{ width: isMobile ? '100%' : 'auto' }}>
                                    <label style={{ 
                                        display: 'block', 
                                        marginBottom: '8px', 
                                        fontWeight: '500', 
                                        color: '#DF6951',
                                        fontSize: isMobile ? '14px' : '16px'
                                    }}>
                                        Max Price: ${filters.hotels.maxPrice}
                                    </label>
                                    <input
                                        type="range"
                                        min="0"
                                        max="1000"
                                        value={filters.hotels.maxPrice}
                                        onChange={(e) => setFilters(prev => ({
                                            ...prev,
                                            hotels: { ...prev.hotels, maxPrice: parseInt(e.target.value) }
                                        }))}
                                        style={{ 
                                            width: isMobile ? '100%' : '200px',
                                            height: isMobile ? '8px' : '6px'
                                        }}
                                    />
                                </div>
                                <div style={{ width: isMobile ? '100%' : 'auto' }}>
                                    <label style={{ 
                                        display: 'block', 
                                        marginBottom: '8px', 
                                        fontWeight: '500', 
                                        color: '#DF6951',
                                        fontSize: isMobile ? '14px' : '16px'
                                    }}>
                                        Min Rating
                                    </label>
                                    <select
                                        value={filters.hotels.minRating}
                                        onChange={(e) => setFilters(prev => ({
                                            ...prev,
                                            hotels: { ...prev.hotels, minRating: parseInt(e.target.value) }
                                        }))}
                                        style={{
                                            padding: isMobile ? '10px 12px' : '8px 12px',
                                            borderRadius: '6px',
                                            border: '1px solid #DF6951',
                                            fontSize: isMobile ? '16px' : '14px',
                                            width: isMobile ? '100%' : 'auto',
                                            backgroundColor: 'white'
                                        }}
                                    >
                                        <option value={0}>Any Rating</option>
                                        <option value={3}>3+ Stars</option>
                                        <option value={4}>4+ Stars</option>
                                        <option value={5}>5 Stars</option>
                                    </select>
                                </div>
                            </div>
                        )}

                        {activeTab === 'restaurants' && (
                            <div style={{ 
                                display: 'flex', 
                                gap: isMobile ? '15px' : '20px', 
                                alignItems: isMobile ? 'flex-start' : 'center', 
                                flexWrap: 'wrap',
                                flexDirection: isMobile ? 'column' : 'row'
                            }}>
                                <div style={{ width: isMobile ? '100%' : 'auto' }}>
                                    <label style={{ 
                                        display: 'block', 
                                        marginBottom: '8px', 
                                        fontWeight: '500', 
                                        color: '#DF6951',
                                        fontSize: isMobile ? '14px' : '16px'
                                    }}>
                                        Cuisine Type
                                    </label>
                                    <select
                                        value={filters.restaurants.cuisine}
                                        onChange={(e) => setFilters(prev => ({
                                            ...prev,
                                            restaurants: { ...prev.restaurants, cuisine: e.target.value }
                                        }))}
                                        style={{
                                            padding: isMobile ? '10px 12px' : '8px 12px',
                                            borderRadius: '6px',
                                            border: '1px solid #DF6951',
                                            fontSize: isMobile ? '16px' : '14px',
                                            width: isMobile ? '100%' : 'auto',
                                            backgroundColor: 'white'
                                        }}
                                    >
                                        <option value="all">All Cuisines</option>
                                        <option value="Indonesian">Indonesian</option>
                                        <option value="Italian">Italian</option>
                                        <option value="Local">Local</option>
                                        <option value="Modern Indonesian">Modern Indonesian</option>
                                    </select>
                                </div>
                                <div style={{ width: isMobile ? '100%' : 'auto' }}>
                                    <label style={{ 
                                        display: 'block', 
                                        marginBottom: '8px', 
                                        fontWeight: '500', 
                                        color: '#DF6951',
                                        fontSize: isMobile ? '14px' : '16px'
                                    }}>
                                        Min Rating
                                    </label>
                                    <select
                                        value={filters.restaurants.minRating}
                                        onChange={(e) => setFilters(prev => ({
                                            ...prev,
                                            restaurants: { ...prev.restaurants, minRating: parseInt(e.target.value) }
                                        }))}
                                        style={{
                                            padding: isMobile ? '10px 12px' : '8px 12px',
                                            borderRadius: '6px',
                                            border: '1px solid #DF6951',
                                            fontSize: isMobile ? '16px' : '14px',
                                            width: isMobile ? '100%' : 'auto',
                                            backgroundColor: 'white'
                                        }}
                                    >
                                        <option value={0}>Any Rating</option>
                                        <option value={3}>3+ Stars</option>
                                        <option value={4}>4+ Stars</option>
                                        <option value={5}>5 Stars</option>
                                    </select>
                                </div>
                            </div>
                        )}

                        {activeTab === 'activities' && (
                            <div style={{ 
                                display: 'flex', 
                                gap: isMobile ? '15px' : '20px', 
                                alignItems: isMobile ? 'flex-start' : 'center', 
                                flexWrap: 'wrap',
                                flexDirection: isMobile ? 'column' : 'row'
                            }}>
                                <div style={{ width: isMobile ? '100%' : 'auto' }}>
                                    <label style={{ 
                                        display: 'block', 
                                        marginBottom: '8px', 
                                        fontWeight: '500', 
                                        color: '#DF6951',
                                        fontSize: isMobile ? '14px' : '16px'
                                    }}>
                                        Difficulty Level
                                    </label>
                                    <select
                                        value={filters.activities.difficulty}
                                        onChange={(e) => setFilters(prev => ({
                                            ...prev,
                                            activities: { ...prev.activities, difficulty: e.target.value }
                                        }))}
                                        style={{
                                            padding: isMobile ? '10px 12px' : '8px 12px',
                                            borderRadius: '6px',
                                            border: '1px solid #DF6951',
                                            fontSize: isMobile ? '16px' : '14px',
                                            width: isMobile ? '100%' : 'auto',
                                            backgroundColor: 'white'
                                        }}
                                    >
                                        <option value="all">All Levels</option>
                                        <option value="Easy">Easy</option>
                                        <option value="Moderate">Moderate</option>
                                        <option value="Hard">Hard</option>
                                    </select>
                                </div>
                                <div style={{ width: isMobile ? '100%' : 'auto' }}>
                                    <label style={{ 
                                        display: 'block', 
                                        marginBottom: '8px', 
                                        fontWeight: '500', 
                                        color: '#DF6951',
                                        fontSize: isMobile ? '14px' : '16px'
                                    }}>
                                        Duration
                                    </label>
                                    <select
                                        value={filters.activities.duration}
                                        onChange={(e) => setFilters(prev => ({
                                            ...prev,
                                            activities: { ...prev.activities, duration: e.target.value }
                                        }))}
                                        style={{
                                            padding: isMobile ? '10px 12px' : '8px 12px',
                                            borderRadius: '6px',
                                            border: '1px solid #DF6951',
                                            fontSize: isMobile ? '16px' : '14px',
                                            width: isMobile ? '100%' : 'auto',
                                            backgroundColor: 'white'
                                        }}
                                    >
                                        <option value="all">Any Duration</option>
                                        <option value="3">3 hours or less</option>
                                        <option value="4">4-6 hours</option>
                                        <option value="8">Full day (8+ hours)</option>
                                    </select>
                                </div>
                            </div>
                        )}
                    </div>

                    {/* Recommendations Grid */}
                    <div style={{
                        display: 'grid',
                        gridTemplateColumns: isMobile ? '1fr' : isTablet ? 'repeat(auto-fill, minmax(280px, 1fr))' : 'repeat(auto-fill, minmax(350px, 1fr))',
                        gap: isMobile ? '12px' : isTablet ? '18px' : '24px'
                    }}>
                        {getFilteredRecommendations(activeTab).length === 0 ? (
                            <div style={{
                                gridColumn: '1 / -1',
                                textAlign: 'center',
                                padding: isMobile ? '30px 10px' : '60px 20px',
                                backgroundColor: 'white',
                                borderRadius: isMobile ? '6px' : '12px',
                                border: '2px dashed #DF6951'
                            }}>
                                <div style={{ fontSize: isMobile ? '36px' : '64px', marginBottom: isMobile ? '8px' : '16px' }}>
                                    {recommendations[activeTab]?.length === 0 ? '📭' : '🔍'}
                                </div>
                                <h3 style={{ 
                                    color: '#DF6951', 
                                    marginBottom: isMobile ? '4px' : '8px',
                                    fontSize: isMobile ? '16px' : '20px'
                                }}>
                                    {recommendations[activeTab]?.length === 0 
                                        ? `No ${activeTab} available` 
                                        : 'No recommendations found'
                                    }
                                </h3>
                                <p style={{ 
                                    color: '#DF6951',
                                    fontSize: isMobile ? '12px' : '16px',
                                    lineHeight: isMobile ? '1.4' : '1.3'
                                }}>
                                    {recommendations[activeTab]?.length === 0 
                                        ? `This destination doesn't have ${activeTab} data yet.` 
                                        : 'Try adjusting your filters to see more options.'
                                    }
                                </p>
                            </div>
                        ) : (
                            getFilteredRecommendations(activeTab).map((item, index) => (
                                <RecommendationCard
                                    key={`${activeTab}-${index}`}
                                    item={item}
                                    type={activeTab}
                                    onAdd={() => addToItinerary(activeTab, item)}
                                    isSelected={selectedItems[activeTab].some(selected => 
                                        (activeTab === 'hotels' && selected.hotelName === item.hotelName) ||
                                        (activeTab === 'restaurants' && selected.restaurantName === item.restaurantName) ||
                                        (activeTab === 'activities' && selected.name === item.name)
                                    )}
                                />
                            ))
                        )}
                    </div>
                </div>

                {/* Sticky Sidebar - Itinerary Preview */}
                <div style={{
                    position: isMobile ? 'relative' : 'sticky',
                    top: isMobile ? 'auto' : '20px',
                    height: 'fit-content',
                    order: isMobile ? -1 : 0,
                    marginBottom: isMobile ? '20px' : '0'
                }}>
                    <div style={{
                        backgroundColor: 'white',
                        borderRadius: isMobile ? '6px' : '12px',
                        padding: isMobile ? '12px' : '24px',
                        boxShadow: isMobile ? '0 2px 8px rgba(0,0,0,0.1)' : '0 8px 25px rgba(0,0,0,0.1)',
                        border: '1px solid #DF6951'
                    }}>
                        <h3 style={{
                            margin: '0 0 12px 0',
                            color: '#F1A501',
                            fontSize: isMobile ? '16px' : '20px',
                            fontWeight: '700',
                            display: 'flex',
                            alignItems: 'center',
                            gap: isMobile ? '4px' : '8px'
                        }}>
                            ✈️ Your Itinerary
                        </h3>
                        {/* Trip Duration Input */}
                        <div style={{ marginBottom: isMobile ? '15px' : '24px' }}>
                            <label style={{
                                display: 'block',
                                marginBottom: '6px',
                                fontWeight: '600',
                                color: '#DF6951',
                                fontSize: isMobile ? '12px' : '14px'
                            }}>
                                Trip Duration (days) *
                            </label>
                            <input
                                type="number"
                                min="1"
                                max="30"
                                value={itinerary.duration}
                                onChange={(e) => setItinerary(prev => ({
                                    ...prev,
                                    duration: e.target.value
                                }))}
                                placeholder="Enter number of days"
                                style={{
                                    width: '100%',
                                    padding: isMobile ? '8px' : '12px',
                                    border: '2px solid #DF6951',
                                    borderRadius: isMobile ? '4px' : '8px',
                                    fontSize: isMobile ? '16px' : '14px',
                                    outline: 'none',
                                    transition: 'border-color 0.2s',
                                    minHeight: isMobile ? '40px' : 'auto'
                                }}
                            />
                        </div>

                        {/* Itinerary Summary */}
                        <div style={{ marginBottom: isMobile ? '15px' : '24px' }}>
                            <div style={{
                                display: 'flex',
                                justifyContent: isMobile ? 'space-around' : 'space-between',
                                padding: isMobile ? '8px' : '12px',
                                backgroundColor: '#F1A501',
                                borderRadius: isMobile ? '4px' : '8px',
                                fontSize: isMobile ? '11px' : '14px',
                                color: 'white',
                                flexWrap: isMobile ? 'wrap' : 'nowrap',
                                gap: isMobile ? '4px' : '0'
                            }}>
                                <span style={{ textAlign: isMobile ? 'center' : 'left' }}>Hotels: {selectedItems.hotels.length}</span>
                                <span style={{ textAlign: isMobile ? 'center' : 'left' }}>Restaurants: {selectedItems.restaurants.length}</span>
                                <span style={{ textAlign: isMobile ? 'center' : 'left' }}>Activities: {selectedItems.activities.length}</span>
                            </div>
                        </div>

                        {/* Selected Items */}
                        {Object.entries(selectedItems).map(([type, items]) => (
                            items.length > 0 && (
                                <div key={type} style={{ marginBottom: isMobile ? '12px' : '20px' }}>
                                    <h4 style={{
                                        color: '#DF6951',
                                        fontSize: isMobile ? '13px' : '16px',
                                        fontWeight: '600',
                                        marginBottom: isMobile ? '8px' : '12px',
                                        textTransform: 'capitalize'
                                    }}>
                                        {type === 'hotels' ? '🏨' : type === 'restaurants' ? '🍽️' : '🎯'} {type}
                                    </h4>
                                    {items.map(item => (
                                        <div key={item.id} style={{
                                            display: 'flex',
                                            justifyContent: 'space-between',
                                            alignItems: 'center',
                                            padding: isMobile ? '8px' : '12px',
                                            backgroundColor: '#F1A501',
                                            borderRadius: isMobile ? '4px' : '8px',
                                            marginBottom: isMobile ? '4px' : '8px',
                                            fontSize: isMobile ? '12px' : '14px',
                                            color: 'white'
                                        }}>
                                            <span style={{ 
                                                fontWeight: '500',
                                                flex: 1,
                                                marginRight: isMobile ? '6px' : '12px',
                                                wordBreak: 'break-word'
                                            }}>
                                                {item.hotelName || item.restaurantName || item.name}
                                            </span>
                                            <button
                                                onClick={() => removeFromItinerary(type, item.id)}
                                                style={{
                                                    background: 'none',
                                                    border: 'none',
                                                    color: '#DF6951',
                                                    cursor: 'pointer',
                                                    fontSize: isMobile ? '12px' : '16px',
                                                    padding: isMobile ? '2px' : '4px',
                                                    minWidth: isMobile ? '20px' : 'auto',
                                                    minHeight: isMobile ? '20px' : 'auto'
                                                }}
                                            >
                                                ✕
                                            </button>
                                        </div>
                                    ))}
                                </div>
                            )
                        ))}

                        {Object.values(selectedItems).every(items => items.length === 0) && (
                            <div style={{
                                textAlign: 'center',
                                padding: isMobile ? '20px 10px' : '40px 20px',
                                color: '#DF6951'
                            }}>
                                <div style={{ fontSize: isMobile ? '28px' : '48px', marginBottom: isMobile ? '6px' : '12px' }}>📝</div>
                                <p style={{ fontSize: isMobile ? '12px' : '16px' }}>Start adding items to build your itinerary!</p>
                            </div>
                        )}
                        {/* Save Button */}
                        {Object.values(selectedItems).some(items => items.length > 0) && (
                            <button
                                onClick={handleSubmit}
                                disabled={isLoading}
                                style={{
                                    width: '100%',
                                    padding: isMobile ? '12px' : '16px',
                                    backgroundColor: isLoading ? '#DF6951' : '#F1A501',
                                    color: 'white',
                                    border: 'none',
                                    borderRadius: isMobile ? '4px' : '8px',
                                    fontSize: isMobile ? '14px' : '16px',
                                    fontWeight: '600',
                                    cursor: isLoading ? 'not-allowed' : 'pointer',
                                    transition: 'all 0.2s ease',
                                    marginTop: isMobile ? '12px' : '20px',
                                    minHeight: isMobile ? '44px' : 'auto'
                                }}
                            >
                                {isLoading ? '⏳ Saving...' : '💾 Save Itinerary'}
                            </button>
                        )}
                    </div>
                </div>
            </div>
        </div>
    );
};

// Recommendation Card Component
const RecommendationCard = ({ item, type, onAdd, isSelected }) => {
    const [isMobile, setIsMobile] = useState(window.innerWidth <= 768);
    
    useEffect(() => {
        const handleResize = () => {
            setIsMobile(window.innerWidth <= 768);
        };
        window.addEventListener('resize', handleResize);
        return () => window.removeEventListener('resize', handleResize);
    }, []);

    const renderStars = (rating) => {
        return Array.from({ length: 5 }, (_, i) => (
            <span key={i} style={{ color: i < rating ? '#F1A501' : '#DF6951', fontSize: isMobile ? '14px' : '16px' }}>
                ★
            </span>
        ));
    };

    const cardStyle = {
        backgroundColor: 'white',
        borderRadius: isMobile ? '8px' : '12px',
        padding: isMobile ? '16px' : '24px',
        boxShadow: '0 4px 6px rgba(0,0,0,0.05)',
        border: '1px solid #DF6951',
        transition: 'all 0.2s ease',
        cursor: 'pointer',
        transform: isSelected ? 'translateY(-2px)' : 'none',
        borderColor: isSelected ? '#F1A501' : '#DF6951',
        position: 'relative'
    };

    return (
        <div style={cardStyle}>
            {isSelected && (
                <div style={{
                    position: 'absolute',
                    top: isMobile ? '8px' : '12px',
                    right: isMobile ? '8px' : '12px',
                    backgroundColor: '#F1A501',
                    color: 'white',
                    borderRadius: '50%',
                    width: isMobile ? '20px' : '24px',
                    height: isMobile ? '20px' : '24px',
                    display: 'flex',
                    alignItems: 'center',
                    justifyContent: 'center',
                    fontSize: isMobile ? '10px' : '12px'
                }}>
                    ✓
                </div>
            )}

            {type === 'hotels' && (
                <>
                    <h3 style={{ 
                        margin: '0 0 12px 0', 
                        color: '#DF6951', 
                        fontSize: isMobile ? '16px' : '18px', 
                        fontWeight: '600',
                        lineHeight: isMobile ? '1.3' : '1.2'
                    }}>
                        {item.hotelName}
                    </h3>
                    <div style={{ 
                        display: 'flex', 
                        alignItems: 'center', 
                        gap: isMobile ? '6px' : '8px', 
                        marginBottom: '12px' 
                    }}>
                        {renderStars(item.rating)}
                        <span style={{ 
                            color: '#F1A501', 
                            fontSize: isMobile ? '12px' : '14px' 
                        }}>
                            ({item.rating}/5)
                        </span>
                    </div>
                    <div style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'space-between',
                        marginBottom: '16px'
                    }}>
                        <span style={{
                            backgroundColor: '#F1A501',
                            color: 'white',
                            padding: isMobile ? '3px 10px' : '4px 12px',
                            borderRadius: '20px',
                            fontSize: isMobile ? '12px' : '14px',
                            fontWeight: '600'
                        }}>
                            ${item.price}/night
                        </span>
                    </div>
                    {item.amenities && item.amenities.length > 0 && (
                        <div style={{ marginBottom: '16px' }}>
                            <div style={{ display: 'flex', flexWrap: 'wrap', gap: isMobile ? '4px' : '6px' }}>
                                {item.amenities.map((amenity, index) => (
                                    <span key={index} style={{
                                        backgroundColor: '#F1A501',
                                        color: 'white',
                                        padding: isMobile ? '3px 6px' : '4px 8px',
                                        borderRadius: '12px',
                                        fontSize: isMobile ? '10px' : '12px'
                                    }}>
                                        {amenity}
                                    </span>
                                ))}
                            </div>
                        </div>
                    )}
                </>
            )}

            {type === 'restaurants' && (
                <>
                    <h3 style={{ 
                        margin: '0 0 12px 0', 
                        color: '#DF6951', 
                        fontSize: isMobile ? '16px' : '18px', 
                        fontWeight: '600',
                        lineHeight: isMobile ? '1.3' : '1.2'
                    }}>
                        {item.restaurantName}
                    </h3>
                    <div style={{ 
                        display: 'flex', 
                        alignItems: 'center', 
                        gap: isMobile ? '6px' : '8px', 
                        marginBottom: '12px' 
                    }}>
                        {renderStars(item.rating)}
                        <span style={{ 
                            color: '#F1A501', 
                            fontSize: isMobile ? '12px' : '14px' 
                        }}>
                            ({item.rating}/5)
                        </span>
                    </div>
                    <div style={{ marginBottom: '16px' }}>
                        <span style={{
                            backgroundColor: '#F1A501',
                            color: 'white',
                            padding: isMobile ? '3px 10px' : '4px 12px',
                            borderRadius: '20px',
                            fontSize: isMobile ? '12px' : '14px',
                            fontWeight: '600',
                            marginRight: '8px'
                        }}>
                            {item.cuisine}
                        </span>
                    </div>
                </>
            )}

            {type === 'activities' && (
                <>
                    <h3 style={{ 
                        margin: '0 0 12px 0', 
                        color: '#DF6951', 
                        fontSize: isMobile ? '16px' : '18px', 
                        fontWeight: '600',
                        lineHeight: isMobile ? '1.3' : '1.2'
                    }}>
                        {item.name}
                    </h3>
                    <div style={{ marginBottom: '16px' }}>
                        <div style={{ 
                            display: 'flex', 
                            flexWrap: 'wrap', 
                            gap: isMobile ? '4px' : '6px', 
                            marginBottom: '8px' 
                        }}>
                            <span style={{
                                backgroundColor: '#F1A501',
                                color: 'white',
                                padding: isMobile ? '3px 10px' : '4px 12px',
                                borderRadius: '20px',
                                fontSize: isMobile ? '12px' : '14px',
                                fontWeight: '600'
                            }}>
                                {item.type}
                            </span>
                            <span style={{
                                backgroundColor: item.difficulty === 'Easy' ? '#F1A501' : item.difficulty === 'Moderate' ? '#F1A501' : '#DF6951',
                                color: 'white',
                                padding: isMobile ? '3px 6px' : '4px 8px',
                                borderRadius: '12px',
                                fontSize: isMobile ? '10px' : '12px'
                            }}>
                                {item.difficulty}
                            </span>
                        </div>
                        <p style={{ 
                            color: '#DF6951', 
                            fontSize: isMobile ? '12px' : '14px', 
                            margin: '8px 0',
                            lineHeight: isMobile ? '1.4' : '1.3'
                        }}>
                            ⏱️ Duration: {item.duration}
                        </p>
                    </div>
                </>
            )}

            <button
                onClick={onAdd}
                disabled={isSelected}
                style={{
                    width: '100%',
                    padding: isMobile ? '10px' : '12px',
                    backgroundColor: isSelected ? '#DF6951' : '#F1A501',
                    color: 'white',
                    border: 'none',
                    borderRadius: isMobile ? '6px' : '8px',
                    fontSize: isMobile ? '13px' : '14px',
                    fontWeight: '600',
                    cursor: isSelected ? 'not-allowed' : 'pointer',
                    transition: 'all 0.2s ease',
                    minHeight: isMobile ? '44px' : 'auto'
                }}
            >
                {isSelected ? '✓ Added to Itinerary' : '+ Add to Itinerary'}
            </button>
        </div>
    );
};

export default CreateItinerary;
