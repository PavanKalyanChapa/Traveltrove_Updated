import React, { useEffect, useState } from "react";
 
import axios from "axios";
import { useAuth } from "../../contexts/AuthContext";
import ItineraryList from "./ItineraryList";
 
const ItineraryPage = () => {
  const {userObj,token} = useAuth();
  const [itineraries, setItineraries] = useState([]);
 
  const [loading, setLoading] = useState(true);
 
  const [error, setError] = useState(null);
 
  useEffect(() => {
 
    const fetchItineraries = async () => {
 
      try {
 
        const response = await axios.get(`http://localhost:5000/triped-itineraries/${userObj.userId}`,
          { headers: { Authorization: `Bearer ${token}` } }
         
        ); // Adjust endpoint if needed
 
        if (response.data && Array.isArray(response.data.itineraries)) {
 
          setItineraries(response.data.itineraries);
 
        } else if (Array.isArray(response.data)) {
 
          setItineraries(response.data);
 
        } else {
 
          setItineraries([]);
 
        }
 
      } catch (err) {
 
        setError("Failed to fetch itineraries");
 
      } finally {
 
        setLoading(false);
 
      }
 
    };
 
    if(userObj) fetchItineraries();
 
  }, [userObj]);
 
  if (loading) return <div>Loading itineraries...</div>;
 
  if (error) return <div>{error}</div>;
 
  return (
 
    <div className="container my-4">
 
      <div className="category-title">
                <h3>All Trip Itineraries</h3>
              </div>
     
 
      {itineraries.length === 0 ? (
 
        <p>No itineraries found.</p>
 
      ) : (
        //  console.log("inside",itineraries)
        <ItineraryList itineraries={itineraries} />
 
      )}
 
    </div>
 
  );
 
};
 
export default ItineraryPage;
 