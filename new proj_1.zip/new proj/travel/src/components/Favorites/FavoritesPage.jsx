import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { FaHeart, FaTrash } from 'react-icons/fa';
import { useAuth } from '../../contexts/AuthContext';
import axios from 'axios';
const FavoritesPage = () => {
  const [favorites, setFavorites] = useState([]);
  const [destinations, setDestinations] = useState({});
  const [itineraries, setItineraries] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const { token, userObj } = useAuth();
  const API_BASE_URL = process.env.REACT_APP_API_BASE_URL || 'http://localhost:5000';
  useEffect(() => {
    if (token) fetchFavorites();
  }, [token]);
  const fetchFavorites = async () => {
    try {
      const response = await fetch(`${API_BASE_URL}/favorites`, {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });
      if (!response.ok) {
        throw new Error('Failed to fetch favorites');
      }
      const data = await response.json();
      setFavorites(data.favorites);
      // Fetch destination details for favorites
      await fetchDestinationDetails(data.favorites);
      // Fetch itinerary details for favorites
      await fetchItineraryDetails(data.favorites);
    } catch (err) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };
  const fetchDestinationDetails = async (favoritesList) => {
    const destinationPromises = favoritesList
      .filter(fav => fav.type === 'destination-guide')
      .map(async (fav) => {
        try {
          const response = await fetch(`${API_BASE_URL}/destination/${fav.id}`);
          if (response.ok) {
            const destination = await response.json();
            return { id: fav.id, data: destination[0] };
          }
        } catch (err) {
          console.error(`Failed to fetch destination ${fav.id}:`, err);
        }
        return null;
      });
    const results = await Promise.all(destinationPromises);
    const destinationsMap = {};
    results.forEach(result => {
      if (result) {
        destinationsMap[result.id] = result.data;
      }
    });
    setDestinations(destinationsMap);
  };

  const fetchItineraryDetails = async (favoritesList) => {
    const itineraryPromises = favoritesList
      .filter(fav => fav.type === 'trip-itinerary')
      .map(async (fav) => {
        try {
          const response = await axios.get(`${API_BASE_URL}/tripeditineraries/${fav.id}`, {
            headers: {
              'Authorization': `Bearer ${token}`,
            },
          });
          if (response.data && response.data.itineraries) {
            const itinerary = response.data.itineraries[0]; // Get first itinerary from array
            console.log(itinerary)
            return { id: fav.id, data: itinerary };
          }
        } catch (err) {
          console.error(`Failed to fetch itinerary ${fav.id}:`, err);
        }
        return null;
      });
    const results = await Promise.all(itineraryPromises);
    const itinerariesMap = {};
    results.forEach(result => {
      if (result) {
        itinerariesMap[result.id] = result.data;
      }
    });
    setItineraries(itinerariesMap);
  };
  const removeFavorite = async (id) => {
    try {
      const response = await fetch(`${API_BASE_URL}/favorites/${id}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json',
        },
      });
      if (!response.ok) {
        throw new Error('Failed to remove favorite');
      }
      // Update local state after removal
      setFavorites((prevFavorites) => prevFavorites.filter(fav => fav.id !== id));
    } catch (err) {
      setError(err.message);
    }
  };
  if (loading) {
    return (
      <div className="favorites-page container mt-5">
        <div className="row justify-content-center">
          <div className="col-md-6 text-center">
            <div className="spinner-border text-primary" role="status">
              <span className="visually-hidden">Loading...</span>
            </div>
            <p className="mt-3 text-muted">Loading your favorites...</p>
          </div>
        </div>
      </div>
    );
  }
  if (error) {
    return (
      <div className="favorites-page container mt-5">
        <div className="row justify-content-center">
          <div className="col-md-6 text-center">
            <div className="alert alert-danger" role="alert">
              <h4 className="alert-heading">Oops!</h4>
              <p>{error}</p>
              <hr />
              <p className="mb-0">Please try refreshing the page or contact support if the problem persists.</p>
            </div>
          </div>
        </div>
      </div>
    );
  }
  if (favorites.length === 0) {
    return (
      <div className="favorites-page container mt-5">
        <div className="row justify-content-center">
          <div className="col-md-6 text-center">
            <div className="card shadow-sm">
              <div className="card-body py-5">
                <FaHeart className="text-muted mb-3" style={{ fontSize: '3rem' }} />
                <h4 className="card-title text-muted">No Favorites Yet</h4>
                <p className="card-text text-muted">Start exploring destinations and add them to your favorites!</p>
                <Link to="/" className="btn btn-primary">Explore Destinations</Link>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
  return (
    <div className="favorites-page container mt-4">
      <div className="row mb-4">
        <div className="col">
          <div className="category-title">
            <h3><FaHeart className="text-danger me-2" style={{height:"40px",marginTop:"-9px"}}/>Your Favorites</h3>
          </div>

        </div>
      </div>
      {/* Favorite Destinations Section */}
      {favorites.filter(fav => fav.type === 'destination-guide' && destinations[fav.id]).length > 0 && (
        <div className="mb-5">
          <h3 className="mb-4">
            <span className="text-dark">🏖️ Favourite Destinations</span>
          </h3>
          <div className="row">
            {favorites
              .filter(fav => fav.type === 'destination-guide' && destinations[fav.id])
              .map((fav, index) => {
                const destination = destinations[fav.id];
                return (
                  <div key={index} className="col-md-6 col-lg-4 mb-4">
                    <div className="card h-100 shadow-sm border-0">
                      {destination.photo && (
                        <img
                          src={destination.photo}
                          className="card-img-top"
                          alt={destination.title}
                          style={{ height: '200px', objectFit: 'cover' }}
                        />
                      )}
                      <div className="card-body d-flex flex-column">
                        <div className="d-flex align-items-center mb-3">
                          <FaHeart className="text-danger me-2" />
                          <h5 className="card-title mb-0">
                            {destination.title}
                          </h5>
                        </div>
                        <p className="card-text text-muted mb-3">
                          {destination.destinationSummary}
                        </p>
                        <div className="mt-auto d-flex gap-2">
                          <Link
                            to={`/destinations/${fav.id}`}
                            className="btn btn-sm flex-fill"
                            style={{ backgroundColor: "#e09401", color: "white" }}
                          >
                            View Details
                          </Link>
                          <button
                            className="btn btn-sm flex-fill"
                            onClick={() => removeFavorite(fav.id)}
                            style={{ backgroundColor: "#DF6951", color: "white" }}
                          >
                            <FaTrash className="me-1" />
                            Remove
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}

      {/* Favorite Itineraries Section */}
      {favorites.filter(fav => fav.type === 'trip-itinerary' && itineraries[fav.id]).length > 0 && (
        <div className="mb-5">
          <h3 className="mb-4">
            <span className="text-dark">✈️ Favorite Itineraries</span>
          </h3>
          <div className="row">
            {favorites
              .filter(fav => fav.type === 'trip-itinerary' && itineraries[fav.id])
              .map((fav, index) => {
                const itinerary = itineraries[fav.id];
                return (
                  <div key={index} className="col-md-6 col-lg-4 mb-4">
                    <div className="card h-100 shadow-sm border-0">
                      <div className="card-body d-flex flex-column">
                        <div className="d-flex align-items-center mb-3">
                          <FaHeart className="text-danger me-2" />
                          <h5 className="card-title mb-0">
                            {itinerary.destination}
                          </h5>
                        </div>

                        <div className="mb-3">
                          <p className="mb-2">
                            <strong>Duration:</strong> {itinerary.duration} days
                          </p>

                          {itinerary.lodging && itinerary.lodging.length > 0 && (
                            <div className="mb-2">
                              <strong>Lodging:</strong>
                              <ul className="mt-1 mb-2">
                                {itinerary.lodging.map((hotel, i) => (
                                  <li key={i} className="small">{hotel}</li>
                                ))}
                              </ul>
                            </div>
                          )}

                          {itinerary.dining && itinerary.dining.length > 0 && (
                            <div className="mb-2">
                              <strong>Dining:</strong>
                              <ul className="mt-1 mb-2">
                                {itinerary.dining.map((restaurant, i) => (
                                  <li key={i} className="small">{restaurant}</li>
                                ))}
                              </ul>
                            </div>
                          )}

                          {itinerary.activities && itinerary.activities.length > 0 && (
                            <div className="mb-2">
                              <strong>Activities:</strong>
                              <ul className="mt-1 mb-2">
                                {itinerary.activities.map((activity, i) => (
                                  <li key={i} className="small">{typeof activity === 'string' ? activity : activity.name}</li>
                                ))}
                              </ul>
                            </div>
                          )}
                        </div>

                        <div className="mt-auto d-flex gap-2">
                          <Link
                            to={`/itineraries`}
                            className="btn btn-sm flex-fill"
                            style={{ backgroundColor: "#e09401", color: "white" }}
                          >
                            View All Itineraries
                          </Link>
                          <button
                            className="btn btn-outline-danger btn-sm flex-fill"
                            onClick={() => removeFavorite(fav.id)}
                            style={{ backgroundColor: "#DF6951", color: "white" }}
                          >
                            <FaTrash className="me-1" />
                            Remove
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      )}
    </div>
  );
};
export default FavoritesPage;