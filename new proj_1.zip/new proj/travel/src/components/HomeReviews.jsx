import React, { useEffect, useState } from "react";
import axios from "axios";
import { Link } from "react-router-dom";
import { FaStar, FaUserCircle, FaMapMarkerAlt, FaQuoteLeft, FaQuoteRight } from "react-icons/fa";
import "./HomeReviews.css";

const HomeReviews = () => {
  const [reviews, setReviews] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    const fetchReviews = async () => {
      setLoading(true);
      setError(null);
      try {
        const response = await axios.get("http://localhost:5000/reviews");
        setReviews(response.data.reviews || []);
      } catch (err) {
        setError("Failed to load reviews");
        console.error("Error fetching reviews:", err);
      } finally {
        setLoading(false);
      }
    };

    fetchReviews();
  }, []);

  // Helper to render stars with animation
  const renderStars = (rating) => {
    return (
      <div className="star-rating">
        {[...Array(5)].map((_, i) => (
          <FaStar
            key={i}
            className={`star-icon ${i < rating ? 'filled' : 'empty'}`}
          />
        ))}
      </div>
    );
  };

  // Helper to format date
  const formatDate = (dateString) => {
    const date = new Date(dateString);
    const now = new Date();
    const diffTime = Math.abs(now - date);
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));

    if (diffDays === 1) return '1 day ago';
    if (diffDays < 7) return `${diffDays} days ago`;
    if (diffDays < 30) return `${Math.floor(diffDays / 7)} weeks ago`;
    if (diffDays < 365) return `${Math.floor(diffDays / 30)} months ago`;
    return `${Math.floor(diffDays / 365)} years ago`;
  };

  return (
    <section className="reviews-section">
      <div className="reviews-container">
        <div className="reviews-header">
          <h2 className="reviews-title">
            What Travelers Say
          </h2>
          <p className="reviews-subtitle">
            Real reviews from our community of explorers
          </p>
        </div>

        {loading && (
          <div className="loading-state">
            <div className="loading-spinner"></div>
            <p>Loading amazing reviews...</p>
          </div>
        )}

        {error && (
          <div className="error-state">
            <div className="error-icon">⚠️</div>
            <p>{error}</p>
            <button className="retry-btn" onClick={() => window.location.reload()}>
              Try Again
            </button>
          </div>
        )}

        {!loading && !error && (
          <>
            <div className="reviews-grid">
              {reviews.slice(0, 4).map((review, idx) => (
                <div key={idx} className="review-card">
                  <div className="review-header">
                    <div className="user-info">
                      <div className="user-avatar">
                        <FaUserCircle />
                      </div>
                      <div className="user-details">
                        <h4 className="user-name">{review.user || "Anonymous Traveler"}</h4>
                        <div className="user-location">
                          <FaMapMarkerAlt className="location-icon" />
                          <span>{review.location || "Location unknown"}</span>
                        </div>
                      </div>
                    </div>
                    <div className="review-rating">
                      {renderStars(review.rating)}
                    </div>
                  </div>

                  <div className="review-content">
                    <FaQuoteLeft className="quote-icon quote-left" />
                    <p className="review-comment">
                      "{review.comment}"
                    </p>
                    <FaQuoteRight className="quote-icon quote-right" />
                  </div>

                  <div className="review-footer">
                    <span className="review-date">
                      {formatDate(review.createdAt)}
                    </span>
                  </div>
                </div>
              ))}
            </div>

            <div className="contact-btn">
              <Link to="/reviews" className="view-all-reviews-btn">
                <span>View All Reviews</span>
                <div className="btn-arrow">→</div>
              </Link>
            </div>
          </>
        )}
      </div>
    </section>
  );
};

export default HomeReviews;


