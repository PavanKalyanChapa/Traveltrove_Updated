const express = require('express')
const app = express()
const create = require('./model/setup_db')
const router = require('./routes/routing')
const bodyParser = require('body-parser');
const cors = require('cors')
require('dotenv').config()


app.use('/set-up-db', (req, res, next) => {
    create.getDB_SetUp().then((data) => {
        res.status(200).send(data)
    }).catch((err) => {
        next(err)
    })
})


app.use('/set-up-itdb', (req, res, next) => {
    create.getItDb_SetUp().then((data) => {
        res.status(200).send(data)
    }).catch((err) => {
        next(err)
    })
})
app.use('/set-up-gpdb', (req, res, next) => {
    create.getGroupDB_SetUp().then((data) => {
        res.status(200).send(data)
    }).catch((err) => {
        next(err)
    })
})

app.use(bodyParser.json())
app.use(cors())
app.use("/api/auth/",router);
app.use('/', router)

app.use((req, res, next) => {
    res.status(404).send("Sorry! Page Not Found...");
});


app.listen(5000, () => console.log("Server running on port 5000"))