const dbModule = require('../utilities/connection')
const mongoose = require('mongoose')
const model = {}
model.generateUserId = (name, email) => {
    // Get current timestamp
    const timestamp = Date.now().toString().slice(-6);  // last 6 digits for uniqueness
    // Take first 3 letters of name (if exists)
    const namePart = name ? name.substring(0, 3).toUpperCase() : "USR";
    // Take 2 letters from email (domain part)
    const emailPart = email ? email.split('@')[0].substring(0, 2).toUpperCase() : "XX";
    // Combine
    const userId = `${namePart}${emailPart}${timestamp}`;
    return userId;
}
model.findDestinations = async () => {
    const dbConnect = await dbModule.getDBModel();
    const destinations = await dbConnect.find({}, { _id: 0, __v: 0 });
    if (destinations.length > 0) {
        return destinations
    } else {
        return null
    }
}
model.findDestinationById = async (destinationId) => {
    const dbConnect = await dbModule.getDBModel();
    const destination = await dbConnect.find({ destinationId: destinationId }, { _id: 0, __v: 0 });
    if (destination) {
        return destination
    } else {
        return null
    }
}
model.addItinerary = async (itinerary) => {
    const dbConnect = await dbModule.getItDb();
    const Itinerary = await dbConnect.create(itinerary);
    if (Itinerary) {
        return Itinerary;
    }
}
model.findItinerary = async (id1, userId) => {
    const dbConnect = await dbModule.getItDb();
    const fetchIti = await dbConnect.find({ destinationId: id1, userId: userId });
    if (fetchIti && fetchIti.length >0) {
        return fetchIti;
    }
}

model.findUserItinerary = async (userId) => {
    const dbConnect = await dbModule.getItDb();
    const fetchIti = await dbConnect.find({ userId: userId });
    if (fetchIti) {
        return fetchIti;
    }
}

model.findItinerarybyItineraryId = async (id) => {
    const dbConnect = await dbModule.getItDb();
    const fetchIti = await dbConnect.find({ id: id });
    if (fetchIti && fetchIti.length >0) {
        return fetchIti;
    }
}
// Favorites Management
model.addFavorite = async (favorite, userId) => {
    const dbConnect = await dbModule.getFavDb();
    // Add userId to the favorite object
    const favoriteWithUser = {
        ...favorite,
        userId: userId
    };
    const Favorite = await dbConnect.create(favoriteWithUser);
    if (Favorite) {
        return Favorite;
    }
}
model.getFavorites = async (userId) => {
    const dbConnect = await dbModule.getFavDb();
    const favorites = await dbConnect.find({ userId: userId }, { _id: 0, __v: 0 });
    if (favorites) {
        return favorites;
    }
    return [];
}
model.removeFavorite = async (id, userId) => {
    const dbConnect = await dbModule.getFavDb();
    const removed = await dbConnect.findOneAndDelete({ id: id, userId: userId });
    if (removed) {
        return removed;
    }
}
// Reviews Management
model.addReview = async (review) => {
    const reviewDb = await dbModule.getReviewDb();
    const Review = await reviewDb.create(review);
    if (Review) {
        return Review;
    }
}
model.getReviews = async (filter) => {
    const reviewDb = await dbModule.getReviewDb();
    const itDb = await dbModule.getItDb();
    const dbConnect = await dbModule.getDBModel();
    // If filtering by type and id, query directly
    if (filter.type && filter.id) {
        const reviews = await reviewDb.find({
            type: filter.type,
            id: filter.id
        });
        return reviews || [];
    }
    let destinationIds = [];
    let itineraryIds = [];
    // If filtering by location, find destination ids
    let destinations = [];
    if (filter.location) {
        destinations = await dbConnect.find({ destinationName: { $regex: filter.location, $options: 'i' } });
        destinationIds = destinations.map(d => d.destinationId);
    }
    // If filtering by activity, find destination and itinerary ids
    let itineraries = [];
    if (filter.activity) {
        const dests = await dbConnect.find({ 'activities.name': { $regex: filter.activity, $options: 'i' } });
        destinationIds = destinationIds.concat(dests.map(d => d.destinationId));
        itineraries = await itDb.find({ activities: { $regex: filter.activity, $options: 'i' } });
        itineraryIds = itineraries.map(i => i.id);
        const reviewDb = await dbModule.getReviewDb();
        const activityReviews = await reviewDb.find({ activities: { $regex: filter.activity, $options: 'i' } })
        const activityReviewIds = activityReviews.map(r => r._id.toString());
        filter._activityReviewIds = activityReviewIds;
    }
    // Remove duplicates
    destinationIds = [...new Set(destinationIds)];
    itineraryIds = [...new Set(itineraryIds)];
    // Build query for reviews
    // let query = {};
    // if (destinationIds.length > 0 || itineraryIds.length > 0 || (filter._activityReviewIds && filter._activityReviewIds.length > 0)) {
    //     query.$or = [];
    //     if (destinationIds.length > 0) {
    //         query.$or.push({ type: "destination-guide", id: { $in: destinationIds } });
    //     }
    //     if (itineraryIds.length > 0) {
    //         query.$or.push({ type: "trip-itinerary", id: { $in: itineraryIds } });
    //     }
    //     if (filter._activityReviewIds && filter._activityReviewIds.length > 0) {
    //         query.$or.push({ _id: { $in: filter._activityReviewIds } });
    //     }
    // }
    // const reviews = await reviewDb.find(query);
    // const reviewsWithActivites = reviews.map(review => {
    //     const baseReview = review.toObject();
    //     if (baseReview.activities && baseReview.activities.length > 0) {
    //         return baseReview;
    //     }
    //     if (review.type === "destination-guide") {
    //         const dest = destinations.find(d => d.destinationId === review.id);
    //         return { ...baseReview, activities: dest ? dest.activities : [] };
    //     } else if (review.type === "trip-itinerary") {
    //         const iti = itineraries.find(i => i.id === review.id);
    //         return { ...baseReview, activities: iti ? iti.activities : [] };
    //     } else {
    //         return baseReview;
    //     }
    // });
    // return reviewsWithActivites || [];

    let query = {};

if (
  destinationIds.length > 0 ||
  itineraryIds.length > 0 ||
  (filter._activityReviewIds && filter._activityReviewIds.length > 0)
) {
  query.$or = [];
  if (destinationIds.length > 0) {
    query.$or.push({
      type: "destination-guide",
      id: { $in: destinationIds },
    });
  }
  if (itineraryIds.length > 0) {
    query.$or.push({
      type: "trip-itinerary",
      id: { $in: itineraryIds },
    });
  }
  if (filter._activityReviewIds && filter._activityReviewIds.length > 0) {
    query.$or.push({ _id: { $in: filter._activityReviewIds } });
  }
} else if (filter.location || filter.activity) {
  // User searched, but no matches found → return empty
  return [];
}

// If no filters provided → fetch all
const reviews = await reviewDb.find(query);
const reviewsWithActivites = reviews.map(review => {
  const baseReview = review.toObject();
  if (baseReview.activities && baseReview.activities.length > 0) {
    return baseReview;
  }
  if (review.type === "destination-guide") {
    const dest = destinations.find(d => d.destinationId === review.id);
    return { ...baseReview, activities: dest ? dest.activities : [] };
  } else if (review.type === "trip-itinerary") {
    const iti = itineraries.find(i => i.id === review.id);
    return { ...baseReview, activities: iti ? iti.activities : [] };
  } else {
    return baseReview;
  }
});

return reviewsWithActivites || [];

}
model.existingUser = async (userObj) => {
    try {
        const modelDb = await dbModule.getUserConnection();
        const userData = await modelDb.findOne({ email: userObj.email });
        console.log(userData);
        if (userData == null) {
            console.log("here")
            return false;
        } else {
            return true;
        }
    } catch (error) {
        throw error;
    }
}
model.addUser = async (userObj) => {
    try {
        const generatedId = model.generateUserId(userObj.name, userObj.email);
        userObj.userId = generatedId;
        const connection = await dbModule.getUserConnection();
        const ack = await connection.create(userObj);
        if (ack) {
            return true;
        } else return false;
    } catch (error) {
        throw error;
    }
}
model.findUser = async (email) => {
    try {
        const connection = await dbModule.getUserConnection();
        const ack = await connection.findOne({ email: email });
        console.log(ack, "I am Here ")
        if (ack) {
            return ack;
        } else return null;
    } catch (error) {
        throw error;
    }
}
//CreateAndJoinGroups - Enhanced for User Story 6
model.generateGroupId = async () => {
    const con = await dbModule.createGroupDB();
    const ids = await con.distinct("groupId");
    if (!ids || ids.length === 0) {
        return 1;
    }
    let bId = Math.max(...ids);
    return bId + 1;
}
model.getGroups = async (userId = null) => {
    const con = await dbModule.createGroupDB();
    const groupsData = await con.find();
    if (groupsData.length > 0) {
        // Add membership status for each group
        const groupsWithMembershipStatus = groupsData.map(group => {
            const groupObj = group.toObject();
            if (userId) {
                const isMember = group.members.some(member => member.userId === userId);
                const isAdmin = group.members.some(member => member.userId === userId && member.role === 'admin');
                groupObj.isMember = isMember;
                groupObj.isAdmin = isAdmin;
            } else {
                groupObj.isMember = false;
                groupObj.isAdmin = false;
            }
            return groupObj;
        });
        return groupsWithMembershipStatus;
    }
    return [];
}
model.createGroup = async (groupData, creatorId) => {
    const con = await dbModule.createGroupDB();
    const userCon = await dbModule.getUserConnection();
    // Check if group name already exists
    const existingGroup = await con.findOne({ groupName: groupData.groupName });
    if (existingGroup) {
        throw new Error("Group name already exists");
    }
    // Get creator details
    const creator = await userCon.findOne({ _id: new mongoose.Types.ObjectId(creatorId) });
    if (!creator) {
        throw new Error("Creator not found");
    }
    const groupId = await model.generateGroupId();
    const newGroupData = {
        groupId: groupId,
        groupName: groupData.groupName,
        description: groupData.description,
        createdBy: creatorId,
        members: [{
            userId: creatorId,
            role: 'admin',
            joinedAt: new Date()
        }],
        createdAt: new Date(),
        updatedAt: new Date()
    };
    const newGroup = await con.create(newGroupData);
    if (newGroup) {
        return newGroup;
    }
}
model.joinGroup = async (groupId, userId, userName) => {
    const con = await dbModule.createGroupDB();
    const group = await con.findOne({ groupId: parseInt(groupId) });
    if (!group) {
        throw new Error("Group not found");
    }
    // Check if user is already a member
    const isMember = group.members.some(member => member.userId === userId);
    if (isMember) {
        throw new Error("You are already a member of this group");
    }
    // Add user to members
    const updatedGroup = await con.findOneAndUpdate(
        { groupId: parseInt(groupId) },
        {
            $push: {
                members: {
                    userId: userId,
                    role: 'member',
                    joinedAt: new Date()
                }
            },
            updatedAt: new Date()
        },
        { new: true }
    );
    if (updatedGroup) {
        return updatedGroup;
    }
}

model.leaveGroup = async (groupId, userId) => {
    const con = await dbModule.createGroupDB();
    const group = await con.findOne({ groupId: parseInt(groupId) });
    if (!group) {
        throw new Error("Group not found");
    }
    // Check if user is a member
    const isMember = group.members.some(member => member.userId === userId);
    if (!isMember) {
        throw new Error("You are not a member of this group");
    }
    // Remove user from members array
    const updatedGroup = await con.findOneAndUpdate(
        { groupId: parseInt(groupId) },
        { $pull: { members: { userId: userId } }, $set: { updatedAt: new Date() } },
        { new: true }
    );
    return updatedGroup;
};


model.getGroupDetails = async (userId) => {
    const con = await dbModule.createGroupDB();
    const group = await con.find({ "members.userId": userId });
    return group;
}

// Admin model functions for destination management
model.addDestination = async (destinationData) => {
    const dbConnect = await dbModule.getDBModel();
    // Generate new destination ID
    const existingDestinations = await dbConnect.find({}, { destinationId: 1 });
    const maxId = existingDestinations.length > 0
        ? Math.max(...existingDestinations.map(d => d.destinationId))
        : 1000;
    destinationData.destinationId = maxId + 1;
    const destination = await dbConnect.create(destinationData);
    return destination;
};
model.updateDestination = async (destinationId, updateData) => {
    const dbConnect = await dbModule.getDBModel();
    const updated = await dbConnect.findOneAndUpdate(
        { destinationId: parseInt(destinationId) },
        updateData,
        { new: true }
    );
    return updated;
};
model.deleteDestination = async (destinationId) => {
    const dbConnect = await dbModule.getDBModel();
    const deleted = await dbConnect.findOneAndDelete({ destinationId: parseInt(destinationId) });
    return deleted;
};
// Admin model functions for itinerary management
model.updateItinerary = async (itineraryId, updateData) => {
    const dbConnect = await dbModule.getItDb();
    const updated = await dbConnect.findOneAndUpdate(
        { id: parseInt(itineraryId) },
        updateData,
        { new: true }
    );
    return updated;
};
model.deleteItinerary = async (itineraryId) => {
    const dbConnect = await dbModule.getItDb();
    const deleted = await dbConnect.findOneAndDelete({ id: parseInt(itineraryId) });
    return deleted;
};
model.getAllItineraries = async () => {
    const dbConnect = await dbModule.getItDb();
    const itineraries = await dbConnect.find({}, { _id: 0, __v: 0 });
    return itineraries;
};
// Admin model functions for review management
model.getAllReviews = async () => {
    const reviewDb = await dbModule.getReviewDb();
    const reviews = await reviewDb.find({});
    return reviews;
};
model.deleteReview = async (reviewId) => {
    const reviewDb = await dbModule.getReviewDb();
    const deleted = await reviewDb.findOneAndDelete({ _id: reviewId });
    return deleted;
};
module.exports = model
