const model = require('../model/model')
const bcrypt = require('bcrypt')
const JWT_SECRET = process.env.JWT_SECRET || "supersecretkey"
const jwt = require('jsonwebtoken');
const service = {}
service.existingUser = async (userObj) => {
    const x = await model.existingUser(userObj);
    console.log("x : ", x)
    return x;
}
 
service.addUser = async (userObj) => {
    const hashedPassword = await bcrypt.hash(userObj.password, 10);
    userObj.password = hashedPassword;
    // console.log(userObj.password);
    if (model.addUser(userObj)) {
        return true;
    }
}
service.loginUser = async (email, password) => {
    const user = await model.findUser(email);
    if (!user) throw new Error("Invalid credentials");
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) throw new Error("Invalid Password");
    const token = jwt.sign({ id: user._id.toString(), email: user.email, role: user.role }, JWT_SECRET, {
        expiresIn: "1h",
    });
    console.log("het is the token ", token);
    // Create user object without password for frontend
    const userForFrontend = {
        userId: user.userId,
        email: user.email,
        name: user.name,
        phoneNumber: user.phoneNumber,
        role: user.role
    };
    return { message: "Login successful", token, user: userForFrontend };
};
// Middleware for token verification
service.authenticateToken = (req, res, next) => {
    const authHeader = req.headers["authorization"];
    const token = authHeader && authHeader.split(" ")[1];
    if (!token) return res.sendStatus(401);
    jwt.verify(token, JWT_SECRET, (err, user) => {
        if (err) return res.sendStatus(403);
        req.user = user;
        next();
    });
};
// Admin middleware for role-based access control
service.requireAdmin = async (req, res, next) => {
    try {
        const user = await model.findUser(req.user.email);
        if (!user || user.role !== 'admin') {
            return res.status(403).json({
                error: "Access denied. Administrator privileges required."
            });
        }
        next();
    } catch (error) {
        return res.status(500).json({
            error: "Error verifying admin privileges"
        });
    }
};
service.findDestinatios = async () => {
    const destinations = await model.findDestinations()
    if (destinations) {
        return destinations
    }
}
service.findDestinationsById = async (destinationId) => {
    const destination = await model.findDestinationById(destinationId);
    if (destination) {
        return destination
    }
}
service.addItinerary = async (itinerary) => {
    const posting = await model.addItinerary(itinerary);
    if (posting) {
        return posting;
    }
}
service.findItinerary = async (id, userId) => {
    const fetch = await model.findItinerary(id, userId);
    if (fetch) {
        return fetch;
    }
}
 
service.findUserItinerary = async (userId)=>{
     const fetch = await model.findUserItinerary(userId);
    if (fetch) {
        return fetch;
    }
}

service.findItinerarybyItineraryId = async (id) => {
    const fetch = await model.findItinerarybyItineraryId(id);
    if (fetch) {
        return fetch;
    }
}

// Favorites Management
service.addFavorite = async (favorite, userId) => {
    const added = await model.addFavorite(favorite, userId);
    if (added) {
        return added;
    }
}
service.getFavorites = async (userId) => {
    const favorites = await model.getFavorites(userId);
    if (favorites) {
        return favorites;
    }
    return [];
}
service.removeFavorite = async (id, userId) => {
    const removed = await model.removeFavorite(id, userId);
    if (removed) {
        return removed;
    }
}
// Reviews Management
service.addReview = async (review) => {
    const added = await model.addReview(review);
    if (added) {
        return added;
    }
}
service.getReviews = async (filter) => {
    const reviews = await model.getReviews(filter);
    if (reviews) {
        return reviews;
    }
    return [];
}
//CreateAndJoinGroups - Enhanced for User Story 6
service.getGroups = async (userId = null) => {
    const groupsData = await model.getGroups(userId);
    if (groupsData) {
        return groupsData;
    }
}
service.createGroup = async (groupData, creatorId) => {
    const newGroup = await model.createGroup(groupData, creatorId);
    if (newGroup) {
        return newGroup;
    }
}
service.joinGroup = async (groupId, userId) => {
    const joinGroup = await model.joinGroup(groupId, userId);
    if (joinGroup) {
        return joinGroup;
    }
}
service.getGroupDetails = async (userId) => {
    const groupDetails = await model.getGroupDetails(userId);
    if (groupDetails) {
        return groupDetails;
    }
}
service.leaveGroup = async (groupId, userId) => {
    const updatedGroup = await model.leaveGroup(groupId, userId);
    return updatedGroup;
};

 
// Admin service functions for destination management
service.addDestination = async (destinationData) => {
    const added = await model.addDestination(destinationData);
    return added;
};
service.updateDestination = async (destinationId, updateData) => {
    const updated = await model.updateDestination(destinationId, updateData);
    return updated;
};
service.deleteDestination = async (destinationId) => {
    const deleted = await model.deleteDestination(destinationId);
    return deleted;
};
// Admin service functions for itinerary management
service.updateItinerary = async (itineraryId, updateData) => {
    const updated = await model.updateItinerary(itineraryId, updateData);
    return updated;
};
service.deleteItinerary = async (itineraryId) => {
    const deleted = await model.deleteItinerary(itineraryId);
    return deleted;
};
service.getAllItineraries = async () => {
    const itineraries = await model.getAllItineraries();
    return itineraries;
};
// Admin service functions for review management
service.getAllReviews = async () => {
    const reviews = await model.getAllReviews();
    return reviews;
};
service.deleteReview = async (reviewId) => {
    const deleted = await model.deleteReview(reviewId);
    return deleted;
};
module.exports = service
 