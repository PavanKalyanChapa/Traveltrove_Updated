const mongoose = require('mongoose');
const bcrypt = require('bcrypt');
// Connect to MongoDB
const url = 'mongodb://localhost:27017/Travel_Trove';
const userSchema = new mongoose.Schema({
    userId: { type: String, unique: true, required: true },
    email: { type: String, unique: true, required: true },
    password: { type: String, required: true },
    name: { type: String, required: true },
    phoneNumber: { type: Number, required: true },
    role: { type: String, enum: ['user', 'admin'], default: 'user' }
});
const createAdminUser = async () => {
    try {
        await mongoose.connect(url);
        console.log('Connected to MongoDB');
        const User = mongoose.model('Users', userSchema);
        // Check if admin already exists
        const existingAdmin = await User.findOne({ email: 'admin@traveltrove.com' });
        if (existingAdmin) {
            console.log('Admin user already exists');
            return;
        }
        // Create admin user
        const hashedPassword = await bcrypt.hash('admin123', 10);
        const adminUser = new User({
            userId: 'ADM001' + Date.now().toString().slice(-6),
            email: 'admin@traveltrove.com',
            password: hashedPassword,
            name: 'Admin User',
            phoneNumber: 1234567890,
            role: 'admin'
        });
        await adminUser.save();
        console.log('Admin user created successfully!');
        console.log('Email: admin@traveltrove.com');
        console.log('Password: admin123');
        
    } catch (error) {
        console.error('Error creating admin user:', error);
    } finally {
        await mongoose.disconnect();
        console.log('Disconnected from MongoDB');
    }
};
createAdminUser();
