const mongoose = require('mongoose')
const url = 'mongodb://localhost:27017/Travel_Trove'
const userSchema = new mongoose.Schema({
    userId: { type: String, unique: true, required: true },
    email: { type: String, unique: true, required: true },
    password: { type: String, required: true },
    name: { type: String, required: true },
    phoneNumber: { type: Number, required: true },
    role: { type: String, enum: ['user', 'admin'], default: 'user' }
});
const connectionOptions = {
    useNewUrlParser: true,
    useUnifiedTopology: true,
    useCreateIndex: true
}
const destinationSchema = mongoose.Schema({
    destinationId: {
        type: Number,
        required: true
    },
    title: {
        type: String,
        required: true
    },
    photo: {
        type: String
    },
    destinationName: {
        type: String,
        required: true
    },
    destinationSummary: {
        type: String,
        required: true
    },
    rating: { type: Number },
    history: { type: String },
    culture: { type: String },
    touristAttractions: [{ type: String }],
    recommendedHotels: [{
        hotelName: { type: String },
        rating: { type: Number },
        price: { type: Number }
    }],
    recommendedRestaurants: [{
        restaurantName: { type: String },
        rating: { type: Number },
        cuisine: { type: String }
    }],
    activities: [{
        name: { type: String },
        type: { type: String },
        difficulty: { type: String },
        duration: { type: String }
    }]
})
const reviewSchema = mongoose.Schema({
    type: {
        type: String,
        required: true
    },
    id: {
        type: Number,
        required: true
    },
    location : {
        type : String,
        required : true
    },
    user: {
        type: String,
        required: true
    },
    rating: {
        type: Number,
        required: true
    },
    comment: {
        type: String,
        required: true
    },
    activities: [{
        type: String
    }],
    createdAt: {
        type: Date,
        default: Date.now
    }
})
const itinerarySchema = mongoose.Schema({
    id: {
        type: Number,
        required: true
    },
    userId: {
        type: String
    },
    destinationId: {
        type: Number,
        required: true
    },
    destination: {
        type: String
    },
    duration: {
        type: String
    },
    activities: [{
        type: String
    }],
    lodging: [{
     type : String
    }],
    dining: [{
        type: String
    }]
})
const favoriteSchema = mongoose.Schema({
    type: {
        type: String,
        required: true
    },
    id: {
        type: Number,
        required: true
    },
    userId: {
        type: String,
        required: true
    }
})
const groupSchema = mongoose.Schema({
    groupId: {
        type: Number,
        required: true,
        unique: true
    },
    groupName: {
        type: String,
        required: true,
        trim: true
    },
    description: {
        type: String,
        required: true
    },
    createdBy: {
        type: String,
        required: true
    },
    members: [{
        userId: {
            type: String,
            required: true
        },
        joinedAt: {
            type: Date,
            default: Date.now
        },
        role: {
            type: String,
            enum: ['admin', 'member'],
            default: 'member'
        }
    }],
    createdAt: {
        type: Date,
        default: Date.now
    },
    updatedAt: {
        type: Date,
        default: Date.now
    }
})

exports.getDBModel = async () => {
    try {
        const dbConnection = await mongoose.connect(url);
        const model = await dbConnection.model("Destinations", destinationSchema);
        return model;
    } catch (error) {
        let err = new Error('Failed to connect with Travel Trove')
        err.status = 500;
        throw err;
    }
}
exports.getReviewDb = async () => {
    try {
        const dbConnection = await mongoose.connect(url);
        const model = await dbConnection.model("Reviews", reviewSchema);
        return model;
    } catch (error) {
        let err = new Error('Failed to connect with Travel Trove')
        err.status = 500;
        throw err;
    }
}
exports.getItDb = async () => {
    try {
        const dbConnection = await mongoose.connect(url);
        const model = await dbConnection.model("Itinerarys", itinerarySchema);
        return model;
    } catch (error) {
        let err = new Error('Failed to connect with Travel Trove')
        err.status = 500;
        throw err;
    }
}
exports.getFavDb = async () => {
    try {
        const dbConnection = await mongoose.connect(url);
        const model = await dbConnection.model("Favorites", favoriteSchema);
        return model;
    } catch (error) {
        let err = new Error('Failed to connect with Travel Trove')
        err.status = 500;
        throw err;
    }
}
exports.getUserConnection = async () => {
    try {
        let dbConnection = await mongoose.connect(url);
        let model = await mongoose.model('Users', userSchema);
        console.log("connected");
        return model;
    } catch (error) {
        const err = new Error("Could not connect to database");
        err.status = 500;
        throw err;
    }
}
exports.createGroupDB = async () => {
    try {
        let dbConnection = await mongoose.connect(url);
        const modelObj = await mongoose.model("Groups", groupSchema);
        return modelObj;
    } catch (error) {
        const err = new Error("Error in connecting the database");
        err.status = 500;
        throw err;
    }
}


